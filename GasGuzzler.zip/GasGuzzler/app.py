import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import time
import os

from components.dashboard import render_dashboard
from components.gas_tracker import render_gas_tracker
from components.transaction_monitor import render_transaction_monitor
from components.network_analyzer import render_network_analyzer
from components.transaction_simulator import render_transaction_simulator
from utils.data_fetcher import DataFetcher

st.set_page_config(
    page_title="Blockchain Analytics Platform",
    page_icon="⛽",
    layout="wide",
    initial_sidebar_state="expanded"
)

@st.cache_resource
def get_data_fetcher():
    return DataFetcher()

def main():
    st.title("⛽ Blockchain Analytics Platform")
    st.markdown("**Comprehensive gas fee tracking, transaction simulation, and network analysis**")
    
    data_fetcher = get_data_fetcher()
    
    st.sidebar.title("Navigation")
    page = st.sidebar.selectbox(
        "Select Page",
        ["Dashboard", "Gas Tracker", "Transactions", "Transaction Monitor", "Network Analyzer"]
    )
    
    st.sidebar.title("Network Selection")
    selected_networks = st.sidebar.multiselect(
        "Choose Networks",
        ["Ethereum", "Polygon", "BSC"],
        default=["Ethereum"]
    )
    
    st.sidebar.title("Settings")
    auto_refresh = st.sidebar.checkbox("Auto Refresh (30s)", value=False)
    
    if page == "Dashboard":
        render_dashboard(data_fetcher, selected_networks)
    elif page == "Gas Tracker":
        render_gas_tracker(data_fetcher, selected_networks)
    elif page == "Transactions":
        render_transaction_simulator()
    elif page == "Transaction Monitor":
        render_transaction_monitor(data_fetcher, selected_networks)
    elif page == "Network Analyzer":
        render_network_analyzer(data_fetcher, selected_networks)
    
    if auto_refresh and page != "Transactions":
        time.sleep(30)
        st.rerun()

if __name__ == "__main__":
    main()
