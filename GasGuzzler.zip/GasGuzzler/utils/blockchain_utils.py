"""
Blockchain utility functions for interacting with different networks
"""
from web3 import Web3
import requests
import os
import time
from typing import Dict, List, Optional, Any
import logging

class BlockchainUtils:
    """Utility class for blockchain operations"""
    
    def __init__(self):
        self.etherscan_api_key = os.getenv("ETHERSCAN_API_KEY", "")
        self.polygonscan_api_key = os.getenv("POLYGONSCAN_API_KEY", "")
        self.bscscan_api_key = os.getenv("BSCSCAN_API_KEY", "")
        
        self.networks = {
            "Ethereum": {
                "rpc_url": "https://eth.llamarpc.com",
                "api_url": "https://api.etherscan.io/api",
                "api_key": self.etherscan_api_key,
                "chain_id": 1,
                "currency": "ETH"
            },
            "Polygon": {
                "rpc_url": "https://polygon.llamarpc.com",
                "api_url": "https://api.polygonscan.com/api",
                "api_key": self.polygonscan_api_key,
                "chain_id": 137,
                "currency": "MATIC"
            },
            "BSC": {
                "rpc_url": "https://bsc-dataseed.binance.org/",
                "api_url": "https://api.bscscan.com/api",
                "api_key": self.bscscan_api_key,
                "chain_id": 56,
                "currency": "BNB"
            }
        }
        
        self.web3_connections = {}
        for network, config in self.networks.items():
            try:
                w3 = Web3(Web3.HTTPProvider(config["rpc_url"], request_kwargs={'timeout': 10}))
                self.web3_connections[network] = w3
            except Exception as e:
                logging.warning(f"Failed to connect to {network}: {e}")
    
    def _is_connected(self, network: str) -> bool:
        """Check if connected to network"""
        try:
            if network in self.web3_connections:
                w3 = self.web3_connections[network]
                return w3.is_connected()
        except Exception:
            pass
        return False
    
    def get_current_gas_price(self, network: str) -> Optional[Dict[str, Any]]:
        """Get current gas price for a network"""
        if network not in self.networks:
            return None
            
        try:
            config = self.networks[network]
            
            if self._is_connected(network):
                w3 = self.web3_connections[network]
                gas_price_wei = w3.eth.gas_price
                gas_price_gwei = float(Web3.from_wei(gas_price_wei, 'gwei'))
                
                safe_price = gas_price_gwei * 0.8
                fast_price = gas_price_gwei * 1.3
                
                return {
                    "network": network,
                    "gas_price_gwei": gas_price_gwei,
                    "safe_gas_price": safe_price,
                    "standard_gas_price": gas_price_gwei,
                    "fast_gas_price": fast_price,
                    "gas_price_wei": int(gas_price_wei),
                    "timestamp": int(time.time())
                }
            
            params = {
                "module": "gastracker",
                "action": "gasoracle",
                "apikey": config["api_key"]
            }
            
            response = requests.get(config["api_url"], params=params, timeout=10)
            data = response.json()
            
            if data.get("status") == "1":
                result = data.get("result", {})
                return {
                    "network": network,
                    "safe_gas_price": float(result.get("SafeGasPrice", 20)),
                    "standard_gas_price": float(result.get("ProposeGasPrice", 25)),
                    "fast_gas_price": float(result.get("FastGasPrice", 35)),
                    "gas_price_gwei": float(result.get("ProposeGasPrice", 25)),
                    "timestamp": int(time.time())
                }
            
            return self._get_simulated_gas_price(network)
                
        except Exception as e:
            logging.error(f"Error getting gas price for {network}: {e}")
            return self._get_simulated_gas_price(network)
    
    def _get_simulated_gas_price(self, network: str) -> Dict[str, Any]:
        """Get simulated gas prices based on typical network values"""
        import random
        
        base_prices = {
            "Ethereum": 25,
            "Polygon": 50,
            "BSC": 5
        }
        
        base = base_prices.get(network, 20)
        variance = random.uniform(0.8, 1.2)
        current_price = base * variance
        
        return {
            "network": network,
            "safe_gas_price": current_price * 0.8,
            "standard_gas_price": current_price,
            "fast_gas_price": current_price * 1.3,
            "gas_price_gwei": current_price,
            "timestamp": int(time.time()),
            "simulated": True
        }
    
    def get_transaction_details(self, network: str, tx_hash: str) -> Optional[Dict[str, Any]]:
        """Get transaction details by hash"""
        if network not in self.networks:
            return None
            
        try:
            config = self.networks[network]
            
            if self._is_connected(network):
                w3 = self.web3_connections[network]
                tx = w3.eth.get_transaction(tx_hash)
                receipt = None
                try:
                    receipt = w3.eth.get_transaction_receipt(tx_hash)
                except:
                    pass
                
                return {
                    "hash": tx.hash.hex() if hasattr(tx.hash, 'hex') else str(tx.hash),
                    "from": tx["from"],
                    "to": tx.get("to"),
                    "value": str(tx["value"]),
                    "gas": tx["gas"],
                    "gas_price": str(tx["gasPrice"]),
                    "status": receipt.status if receipt else None,
                    "block_number": tx.get("blockNumber"),
                    "network": network
                }
            
            params = {
                "module": "proxy",
                "action": "eth_getTransactionByHash",
                "txhash": tx_hash,
                "apikey": config["api_key"]
            }
            
            response = requests.get(config["api_url"], params=params, timeout=10)
            data = response.json()
            
            if data.get("result"):
                return {
                    "hash": data["result"].get("hash"),
                    "from": data["result"].get("from"),
                    "to": data["result"].get("to"),
                    "value": data["result"].get("value"),
                    "gas": int(data["result"].get("gas", "0"), 16),
                    "gas_price": str(int(data["result"].get("gasPrice", "0"), 16)),
                    "block_number": int(data["result"].get("blockNumber", "0"), 16) if data["result"].get("blockNumber") else None,
                    "network": network
                }
                
        except Exception as e:
            logging.error(f"Error getting transaction details for {network}: {e}")
        
        return None
    
    def get_network_stats(self, network: str) -> Optional[Dict[str, Any]]:
        """Get network statistics"""
        if network not in self.networks:
            return None
            
        try:
            config = self.networks[network]
            stats = {"network": network}
            
            if self._is_connected(network):
                w3 = self.web3_connections[network]
                latest_block = w3.eth.get_block('latest')
                stats.update({
                    "latest_block": latest_block.number,
                    "block_time": latest_block.timestamp,
                    "gas_limit": latest_block.gasLimit,
                    "gas_used": latest_block.gasUsed,
                    "network_utilization": (latest_block.gasUsed / latest_block.gasLimit) * 100
                })
                return stats
            
            return self._get_simulated_network_stats(network)
            
        except Exception as e:
            logging.error(f"Error getting network stats for {network}: {e}")
            return self._get_simulated_network_stats(network)
    
    def _get_simulated_network_stats(self, network: str) -> Dict[str, Any]:
        """Get simulated network statistics"""
        import random
        
        block_bases = {
            "Ethereum": 19000000,
            "Polygon": 55000000,
            "BSC": 38000000
        }
        
        gas_limits = {
            "Ethereum": 30000000,
            "Polygon": 30000000,
            "BSC": 140000000
        }
        
        base_block = block_bases.get(network, 19000000)
        gas_limit = gas_limits.get(network, 30000000)
        utilization = random.uniform(40, 85)
        gas_used = int(gas_limit * (utilization / 100))
        
        return {
            "network": network,
            "latest_block": base_block + random.randint(0, 100000),
            "block_time": int(time.time()),
            "gas_limit": gas_limit,
            "gas_used": gas_used,
            "network_utilization": utilization,
            "simulated": True
        }
    
    def estimate_transaction_cost(self, network: str, gas_limit: int, gas_price_gwei: float) -> Dict[str, float]:
        """Estimate transaction cost"""
        try:
            gas_cost_eth = (gas_limit * gas_price_gwei) / 1e9
            
            eth_usd_rate = 2000
            
            if network == "Polygon":
                eth_usd_rate = 0.8
            elif network == "BSC":
                eth_usd_rate = 300
                
            cost_usd = gas_cost_eth * eth_usd_rate
            
            return {
                "gas_limit": gas_limit,
                "gas_price_gwei": gas_price_gwei,
                "cost_eth": gas_cost_eth,
                "cost_usd": cost_usd,
                "network": network
            }
            
        except Exception as e:
            logging.error(f"Error estimating transaction cost: {e}")
            return {}
