"""
Transaction simulator for multi-cryptocurrency support
"""
import hashlib
import secrets
import time
import random
import string
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import threading

class TransactionSimulator:
    """Simulates cryptocurrency transactions with realistic data"""
    
    SUPPORTED_CRYPTOS = {
        "BTC": {
            "name": "Bitcoin",
            "symbol": "BTC",
            "decimals": 8,
            "avg_fee": 0.0001,
            "block_time": 600,
            "confirmations_required": 6,
            "address_prefix": "1",
            "address_length": 34
        },
        "ETH": {
            "name": "Ethereum",
            "symbol": "ETH",
            "decimals": 18,
            "avg_fee": 0.002,
            "block_time": 12,
            "confirmations_required": 12,
            "address_prefix": "0x",
            "address_length": 42
        },
        "LTC": {
            "name": "Litecoin",
            "symbol": "LTC",
            "decimals": 8,
            "avg_fee": 0.0001,
            "block_time": 150,
            "confirmations_required": 6,
            "address_prefix": "L",
            "address_length": 34
        },
        "USDT": {
            "name": "Tether",
            "symbol": "USDT",
            "decimals": 6,
            "avg_fee": 1.0,
            "block_time": 12,
            "confirmations_required": 12,
            "address_prefix": "0x",
            "address_length": 42
        },
        "USDC": {
            "name": "USD Coin",
            "symbol": "USDC",
            "decimals": 6,
            "avg_fee": 1.0,
            "block_time": 12,
            "confirmations_required": 12,
            "address_prefix": "0x",
            "address_length": 42
        },
        "BNB": {
            "name": "Binance Coin",
            "symbol": "BNB",
            "decimals": 18,
            "avg_fee": 0.0005,
            "block_time": 3,
            "confirmations_required": 15,
            "address_prefix": "0x",
            "address_length": 42
        },
        "XRP": {
            "name": "Ripple",
            "symbol": "XRP",
            "decimals": 6,
            "avg_fee": 0.00001,
            "block_time": 4,
            "confirmations_required": 1,
            "address_prefix": "r",
            "address_length": 34
        },
        "DOGE": {
            "name": "Dogecoin",
            "symbol": "DOGE",
            "decimals": 8,
            "avg_fee": 1.0,
            "block_time": 60,
            "confirmations_required": 6,
            "address_prefix": "D",
            "address_length": 34
        },
        "SOL": {
            "name": "Solana",
            "symbol": "SOL",
            "decimals": 9,
            "avg_fee": 0.00025,
            "block_time": 0.4,
            "confirmations_required": 32,
            "address_prefix": "",
            "address_length": 44
        },
        "MATIC": {
            "name": "Polygon",
            "symbol": "MATIC",
            "decimals": 18,
            "avg_fee": 0.01,
            "block_time": 2,
            "confirmations_required": 128,
            "address_prefix": "0x",
            "address_length": 42
        }
    }
    
    TARGET_WALLET_MIN_USD = 15000
    
    BASE_PRICES = {
        "BTC": 45000.0,
        "ETH": 2500.0,
        "LTC": 70.0,
        "USDT": 1.0,
        "USDC": 1.0,
        "BNB": 300.0,
        "XRP": 0.60,
        "DOGE": 0.08,
        "SOL": 100.0,
        "MATIC": 0.80
    }
    
    def __init__(self):
        self.wallets = {}
        self.target_wallets = {}
        self.transactions = []
        self.transaction_lock = threading.Lock()
        self._confirmation_thread = None
        self._running = False
        self._initialize_target_wallets()
    
    def _initialize_target_wallets(self):
        """Initialize pre-loaded target wallets with balances >= $15,000 USD"""
        for crypto in self.SUPPORTED_CRYPTOS:
            self._create_target_wallet(crypto)
    
    def _create_target_wallet(self, crypto: str) -> Dict[str, Any]:
        """Create a target wallet with balance >= $15,000 USD"""
        config = self.SUPPORTED_CRYPTOS[crypto]
        price = self.BASE_PRICES.get(crypto, 100.0)
        
        min_balance = self.TARGET_WALLET_MIN_USD / price
        max_balance = (self.TARGET_WALLET_MIN_USD * 5) / price
        balance = random.uniform(min_balance, max_balance)
        
        prefix = config["address_prefix"]
        length = config["address_length"]
        
        if prefix == "0x":
            address = "0x" + secrets.token_hex(20)
        elif prefix == "":
            chars = string.ascii_letters + string.digits
            address = ''.join(random.choices(chars, k=length))
        else:
            chars = string.ascii_letters.replace('I', '').replace('O', '').replace('l', '') + string.digits
            remaining_length = length - len(prefix)
            address = prefix + ''.join(random.choices(chars, k=remaining_length))
        
        private_key = secrets.token_hex(32)
        wallet_id = secrets.token_hex(8)
        
        wallet = {
            "id": wallet_id,
            "crypto": crypto,
            "name": config["name"],
            "symbol": config["symbol"],
            "address": address,
            "private_key": private_key,
            "balance": balance,
            "initial_balance": balance,
            "is_target": True,
            "created_at": datetime.now().isoformat()
        }
        
        self.target_wallets[crypto] = wallet
        return wallet
    
    def get_target_wallet(self, crypto: str) -> Optional[Dict[str, Any]]:
        """Get the target wallet for a specific crypto"""
        return self.target_wallets.get(crypto)
    
    def get_all_target_wallets(self) -> Dict[str, Dict[str, Any]]:
        """Get all target wallets"""
        return self.target_wallets.copy()
    
    def load_target_wallet(self, crypto: str) -> Dict[str, Any]:
        """Load (or reload) a target wallet for a specific crypto"""
        if crypto not in self.SUPPORTED_CRYPTOS:
            return {"error": f"Unsupported cryptocurrency: {crypto}"}
        
        wallet = self._create_target_wallet(crypto)
        return wallet
    
    def get_wallet_balance_usd(self, crypto: str) -> float:
        """Get the target wallet balance in USD"""
        wallet = self.target_wallets.get(crypto)
        if not wallet:
            return 0.0
        price = self.BASE_PRICES.get(crypto, 100.0)
        return wallet["balance"] * price
    
    def update_wallet_balance(self, crypto: str, amount: float) -> bool:
        """Deduct amount from target wallet balance"""
        if crypto not in self.target_wallets:
            return False
        
        wallet = self.target_wallets[crypto]
        if wallet["balance"] < amount:
            return False
        
        wallet["balance"] -= amount
        return True
    
    def generate_wallet_address(self, crypto: str) -> Dict[str, str]:
        """Generate a realistic wallet address for the specified cryptocurrency"""
        if crypto not in self.SUPPORTED_CRYPTOS:
            return {"error": f"Unsupported cryptocurrency: {crypto}"}
        
        config = self.SUPPORTED_CRYPTOS[crypto]
        prefix = config["address_prefix"]
        length = config["address_length"]
        
        if prefix == "0x":
            address = "0x" + secrets.token_hex(20)
        elif prefix == "":
            chars = string.ascii_letters + string.digits
            address = ''.join(random.choices(chars, k=length))
        else:
            chars = string.ascii_letters.replace('I', '').replace('O', '').replace('l', '') + string.digits
            remaining_length = length - len(prefix)
            address = prefix + ''.join(random.choices(chars, k=remaining_length))
        
        private_key = secrets.token_hex(32)
        
        wallet_id = secrets.token_hex(8)
        
        wallet = {
            "id": wallet_id,
            "crypto": crypto,
            "name": config["name"],
            "symbol": config["symbol"],
            "address": address,
            "private_key": private_key,
            "balance": random.uniform(0.1, 10.0),
            "created_at": datetime.now().isoformat()
        }
        
        if crypto not in self.wallets:
            self.wallets[crypto] = []
        self.wallets[crypto].append(wallet)
        
        return wallet
    
    def get_wallets(self, crypto: str = None) -> List[Dict[str, Any]]:
        """Get all wallets, optionally filtered by crypto"""
        if crypto:
            return self.wallets.get(crypto, [])
        
        all_wallets = []
        for crypto_wallets in self.wallets.values():
            all_wallets.extend(crypto_wallets)
        return all_wallets
    
    def generate_transaction_hash(self, crypto: str) -> str:
        """Generate a realistic transaction hash"""
        if crypto in ["BTC", "LTC", "DOGE"]:
            return secrets.token_hex(32)
        elif crypto in ["ETH", "USDT", "USDC", "BNB", "MATIC"]:
            return "0x" + secrets.token_hex(32)
        elif crypto == "XRP":
            chars = string.ascii_uppercase + string.digits
            return ''.join(random.choices(chars, k=64))
        elif crypto == "SOL":
            chars = string.ascii_letters + string.digits
            return ''.join(random.choices(chars, k=88))
        else:
            return secrets.token_hex(32)
    
    def generate_transaction_id(self) -> str:
        """Generate a unique transaction ID"""
        timestamp = int(time.time() * 1000)
        random_part = secrets.token_hex(4)
        return f"TX{timestamp}{random_part}".upper()
    
    def create_transaction(
        self,
        crypto: str,
        from_address: str,
        to_address: str,
        amount: float,
        fee: float = None,
        memo: str = "",
        use_target_wallet: bool = True
    ) -> Dict[str, Any]:
        """Create a simulated transaction with balance deduction"""
        if crypto not in self.SUPPORTED_CRYPTOS:
            return {"error": f"Unsupported cryptocurrency: {crypto}"}
        
        config = self.SUPPORTED_CRYPTOS[crypto]
        
        if fee is None:
            fee = config["avg_fee"] * random.uniform(0.8, 1.5)
        
        total_amount = amount + fee
        balance_before = 0.0
        balance_after = 0.0
        
        target_wallet = self.target_wallets.get(crypto)
        if use_target_wallet and target_wallet:
            balance_before = target_wallet["balance"]
            
            if balance_before < total_amount:
                price = self.BASE_PRICES.get(crypto, 100.0)
                return {
                    "error": f"Insufficient balance. Available: {balance_before:.8f} {config['symbol']} (${balance_before * price:,.2f}), Required: {total_amount:.8f} {config['symbol']} (${total_amount * price:,.2f})"
                }
            
            target_wallet["balance"] -= total_amount
            balance_after = target_wallet["balance"]
            from_address = target_wallet["address"]
        
        tx_hash = self.generate_transaction_hash(crypto)
        tx_id = self.generate_transaction_id()
        
        block_number = self._generate_block_number(crypto)
        price = self.BASE_PRICES.get(crypto, 100.0)
        
        transaction = {
            "id": tx_id,
            "hash": tx_hash,
            "crypto": crypto,
            "symbol": config["symbol"],
            "name": config["name"],
            "from_address": from_address,
            "to_address": to_address,
            "amount": amount,
            "fee": fee,
            "total": total_amount,
            "amount_usd": amount * price,
            "fee_usd": fee * price,
            "total_usd": total_amount * price,
            "balance_before": balance_before,
            "balance_after": balance_after,
            "balance_before_usd": balance_before * price,
            "balance_after_usd": balance_after * price,
            "memo": memo,
            "status": "pending",
            "confirmations": 0,
            "confirmations_required": config["confirmations_required"],
            "block_number": None,
            "block_hash": None,
            "nonce": random.randint(0, 1000000),
            "gas_limit": random.randint(21000, 100000) if crypto in ["ETH", "USDT", "USDC", "BNB", "MATIC"] else None,
            "gas_price": random.uniform(10, 100) if crypto in ["ETH", "USDT", "USDC", "BNB", "MATIC"] else None,
            "created_at": datetime.now().isoformat(),
            "confirmed_at": None,
            "updated_at": datetime.now().isoformat(),
            "network": self._get_network_name(crypto),
            "estimated_block": block_number
        }
        
        with self.transaction_lock:
            self.transactions.append(transaction)
        
        return transaction
    
    def _generate_block_number(self, crypto: str) -> int:
        """Generate a realistic block number for the crypto"""
        block_bases = {
            "BTC": 820000,
            "ETH": 19000000,
            "LTC": 2600000,
            "USDT": 19000000,
            "USDC": 19000000,
            "BNB": 35000000,
            "XRP": 85000000,
            "DOGE": 5000000,
            "SOL": 250000000,
            "MATIC": 55000000
        }
        base = block_bases.get(crypto, 1000000)
        return base + random.randint(0, 10000)
    
    def _get_network_name(self, crypto: str) -> str:
        """Get the network name for a crypto"""
        networks = {
            "BTC": "Bitcoin Mainnet",
            "ETH": "Ethereum Mainnet",
            "LTC": "Litecoin Mainnet",
            "USDT": "Ethereum (ERC-20)",
            "USDC": "Ethereum (ERC-20)",
            "BNB": "BSC Mainnet",
            "XRP": "XRP Ledger",
            "DOGE": "Dogecoin Mainnet",
            "SOL": "Solana Mainnet",
            "MATIC": "Polygon Mainnet"
        }
        return networks.get(crypto, f"{crypto} Network")
    
    def update_confirmation(self, tx_id: str, new_confirmations: int) -> Optional[Dict[str, Any]]:
        """Update confirmation count for a transaction"""
        with self.transaction_lock:
            for tx in self.transactions:
                if tx["id"] == tx_id:
                    tx["confirmations"] = new_confirmations
                    tx["updated_at"] = datetime.now().isoformat()
                    
                    if new_confirmations >= tx["confirmations_required"]:
                        tx["status"] = "confirmed"
                        tx["confirmed_at"] = datetime.now().isoformat()
                        tx["block_number"] = tx["estimated_block"]
                        tx["block_hash"] = secrets.token_hex(32)
                    elif new_confirmations > 0:
                        tx["status"] = "confirming"
                        tx["block_number"] = tx["estimated_block"]
                        tx["block_hash"] = secrets.token_hex(32)
                    else:
                        tx["status"] = "pending"
                        tx["block_number"] = None
                        tx["block_hash"] = None
                    
                    return tx.copy()
        return None
    
    def set_transaction_status(self, tx_id: str, status: str) -> Optional[Dict[str, Any]]:
        """Set transaction status manually"""
        valid_statuses = ["pending", "confirming", "confirmed", "failed", "cancelled"]
        if status not in valid_statuses:
            return None
        
        with self.transaction_lock:
            for tx in self.transactions:
                if tx["id"] == tx_id:
                    tx["status"] = status
                    tx["updated_at"] = datetime.now().isoformat()
                    
                    if status == "confirmed":
                        tx["confirmations"] = tx["confirmations_required"]
                        tx["confirmed_at"] = datetime.now().isoformat()
                        tx["block_number"] = tx["estimated_block"]
                        tx["block_hash"] = secrets.token_hex(32)
                    elif status == "pending":
                        tx["confirmations"] = 0
                        tx["confirmed_at"] = None
                        tx["block_number"] = None
                        tx["block_hash"] = None
                    
                    return tx.copy()
        return None
    
    def get_transaction(self, tx_id: str = None, tx_hash: str = None) -> Optional[Dict[str, Any]]:
        """Get a specific transaction by ID or hash"""
        with self.transaction_lock:
            for tx in self.transactions:
                if (tx_id and tx["id"] == tx_id) or (tx_hash and tx["hash"] == tx_hash):
                    return tx.copy()
        return None
    
    def get_transactions(
        self,
        crypto: str = None,
        status: str = None,
        limit: int = 50,
        address: str = None
    ) -> List[Dict[str, Any]]:
        """Get transactions with optional filters"""
        with self.transaction_lock:
            filtered = self.transactions.copy()
        
        if crypto:
            filtered = [tx for tx in filtered if tx["crypto"] == crypto]
        
        if status:
            filtered = [tx for tx in filtered if tx["status"] == status]
        
        if address:
            filtered = [tx for tx in filtered 
                       if tx["from_address"] == address or tx["to_address"] == address]
        
        filtered.sort(key=lambda x: x["created_at"], reverse=True)
        
        return filtered[:limit]
    
    def get_pending_transactions(self) -> List[Dict[str, Any]]:
        """Get all pending and confirming transactions"""
        with self.transaction_lock:
            return [tx.copy() for tx in self.transactions 
                   if tx["status"] in ["pending", "confirming"]]
    
    def simulate_confirmation_progress(self):
        """Simulate confirmation progress for pending transactions"""
        with self.transaction_lock:
            for tx in self.transactions:
                if tx["status"] in ["pending", "confirming"]:
                    config = self.SUPPORTED_CRYPTOS.get(tx["crypto"], {})
                    block_time = config.get("block_time", 60)
                    
                    created = datetime.fromisoformat(tx["created_at"])
                    elapsed = (datetime.now() - created).total_seconds()
                    
                    expected_confirmations = int(elapsed / block_time)
                    expected_confirmations = min(
                        expected_confirmations,
                        tx["confirmations_required"] + 5
                    )
                    
                    if expected_confirmations > tx["confirmations"]:
                        tx["confirmations"] = expected_confirmations
                        tx["updated_at"] = datetime.now().isoformat()
                        
                        if expected_confirmations >= tx["confirmations_required"]:
                            tx["status"] = "confirmed"
                            tx["confirmed_at"] = datetime.now().isoformat()
                            tx["block_number"] = tx["estimated_block"]
                            tx["block_hash"] = secrets.token_hex(32)
                        elif expected_confirmations > 0:
                            tx["status"] = "confirming"
                            tx["block_number"] = tx["estimated_block"]
                            tx["block_hash"] = secrets.token_hex(32)
    
    def get_crypto_price(self, crypto: str) -> Dict[str, float]:
        """Get simulated current price for a cryptocurrency"""
        base_prices = {
            "BTC": 45000.0,
            "ETH": 2500.0,
            "LTC": 70.0,
            "USDT": 1.0,
            "USDC": 1.0,
            "BNB": 300.0,
            "XRP": 0.60,
            "DOGE": 0.08,
            "SOL": 100.0,
            "MATIC": 0.80
        }
        
        base = base_prices.get(crypto, 100.0)
        
        if crypto in ["USDT", "USDC"]:
            variance = random.uniform(0.999, 1.001)
        else:
            variance = random.uniform(0.95, 1.05)
        
        price = base * variance
        change_24h = random.uniform(-5, 5)
        
        return {
            "crypto": crypto,
            "symbol": self.SUPPORTED_CRYPTOS.get(crypto, {}).get("symbol", crypto),
            "price_usd": price,
            "change_24h": change_24h,
            "updated_at": datetime.now().isoformat()
        }
    
    def get_all_prices(self) -> Dict[str, Dict[str, float]]:
        """Get prices for all supported cryptocurrencies"""
        prices = {}
        for crypto in self.SUPPORTED_CRYPTOS:
            prices[crypto] = self.get_crypto_price(crypto)
        return prices
    
    def get_transaction_stats(self) -> Dict[str, Any]:
        """Get transaction statistics"""
        with self.transaction_lock:
            total = len(self.transactions)
            pending = len([tx for tx in self.transactions if tx["status"] == "pending"])
            confirming = len([tx for tx in self.transactions if tx["status"] == "confirming"])
            confirmed = len([tx for tx in self.transactions if tx["status"] == "confirmed"])
            failed = len([tx for tx in self.transactions if tx["status"] == "failed"])
            
            by_crypto = {}
            for tx in self.transactions:
                crypto = tx["crypto"]
                if crypto not in by_crypto:
                    by_crypto[crypto] = {"count": 0, "volume": 0}
                by_crypto[crypto]["count"] += 1
                by_crypto[crypto]["volume"] += tx["amount"]
        
        return {
            "total_transactions": total,
            "pending": pending,
            "confirming": confirming,
            "confirmed": confirmed,
            "failed": failed,
            "by_crypto": by_crypto,
            "updated_at": datetime.now().isoformat()
        }
    
    def clear_transactions(self):
        """Clear all transactions"""
        with self.transaction_lock:
            self.transactions.clear()
    
    def clear_wallets(self):
        """Clear all wallets"""
        self.wallets.clear()
