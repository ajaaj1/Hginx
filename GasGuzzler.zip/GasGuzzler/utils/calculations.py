"""
Calculation utilities for blockchain analytics
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Tuple
from datetime import datetime, timedelta

class CalculationEngine:
    """Engine for performing blockchain-related calculations"""
    
    @staticmethod
    def calculate_transaction_cost(gas_limit: int, gas_price_gwei: float, network: str) -> Dict[str, Any]:
        """Calculate transaction cost in native currency and USD"""
        try:
            # Gas cost in native currency (ETH, MATIC, BNB)
            gas_cost_native = (gas_limit * gas_price_gwei) / 1e9
            
            # Approximate exchange rates (in real app, fetch from price APIs)
            exchange_rates = {
                "Ethereum": 2000.0,  # ETH/USD
                "Polygon": 0.8,      # MATIC/USD
                "BSC": 300.0         # BNB/USD
            }
            
            rate = exchange_rates.get(network, 2000.0)
            cost_usd = gas_cost_native * rate
            
            return {
                "gas_limit": gas_limit,
                "gas_price_gwei": gas_price_gwei,
                "gas_cost_native": gas_cost_native,
                "cost_usd": cost_usd,
                "exchange_rate": rate,
                "network": network,
                "currency": "ETH" if network == "Ethereum" else "MATIC" if network == "Polygon" else "BNB"
            }
            
        except Exception as e:
            return {"error": str(e)}
    
    @staticmethod
    def calculate_gas_savings(current_price: float, optimal_price: float, gas_limit: int) -> Dict[str, Any]:
        """Calculate potential gas savings"""
        try:
            current_cost = (gas_limit * current_price) / 1e9
            optimal_cost = (gas_limit * optimal_price) / 1e9
            
            savings_native = current_cost - optimal_cost
            savings_percentage = (savings_native / current_cost) * 100 if current_cost > 0 else 0
            
            return {
                "current_cost": current_cost,
                "optimal_cost": optimal_cost,
                "savings_native": savings_native,
                "savings_percentage": savings_percentage,
                "gas_limit": gas_limit
            }
            
        except Exception as e:
            return {"error": str(e)}
    
    @staticmethod
    def analyze_gas_trends(df: pd.DataFrame, window: int = 20) -> Dict[str, Any]:
        """Analyze gas price trends from historical data"""
        try:
            if df.empty or 'price' not in df.columns:
                return {"error": "No data available for analysis"}
            
            prices = df['price'].values
            
            if len(prices) < 2:
                return {"error": "Insufficient data for trend analysis"}
            
            # Calculate moving average
            if len(prices) >= window:
                moving_avg = np.convolve(prices, np.ones(window)/window, mode='valid')
                current_ma = moving_avg[-1]
                previous_ma = moving_avg[-2] if len(moving_avg) > 1 else moving_avg[-1]
            else:
                current_ma = np.mean(prices)
                previous_ma = current_ma
            
            # Calculate trend
            trend_direction = "increasing" if current_ma > previous_ma else "decreasing" if current_ma < previous_ma else "stable"
            trend_strength = abs(current_ma - previous_ma) / previous_ma * 100 if previous_ma > 0 else 0
            
            # Statistical analysis
            stats = {
                "current_price": float(prices[-1]),
                "average_price": float(np.mean(prices)),
                "median_price": float(np.median(prices)),
                "min_price": float(np.min(prices)),
                "max_price": float(np.max(prices)),
                "std_deviation": float(np.std(prices)),
                "volatility": float(np.std(prices) / np.mean(prices) * 100) if np.mean(prices) > 0 else 0,
                "trend_direction": trend_direction,
                "trend_strength": float(trend_strength),
                "moving_average": float(current_ma),
                "price_change_24h": float((prices[-1] - prices[0]) / prices[0] * 100) if prices[0] > 0 else 0
            }
            
            return stats
            
        except Exception as e:
            return {"error": str(e)}
    
    @staticmethod
    def predict_optimal_timing(gas_history: pd.DataFrame, target_price: float = None) -> Dict[str, Any]:
        """Predict optimal timing for transactions based on historical patterns"""
        try:
            if gas_history.empty or 'timestamp' not in gas_history.columns or 'price' not in gas_history.columns:
                return {"error": "Insufficient data for timing prediction"}
            
            df = gas_history.copy()
            df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
            df['day_of_week'] = pd.to_datetime(df['timestamp']).dt.dayofweek
            
            # Analyze patterns by hour and day
            hourly_avg = df.groupby('hour')['price'].mean()
            daily_avg = df.groupby('day_of_week')['price'].mean()
            
            best_hour = hourly_avg.idxmin()
            best_day = daily_avg.idxmin()
            
            current_price = df['price'].iloc[-1] if not df.empty else 0
            
            if target_price is None:
                target_price = hourly_avg.min()
            
            # Estimate when target price might be reached
            recent_trend = df['price'].tail(10).mean() if len(df) >= 10 else current_price
            
            prediction = {
                "current_price": float(current_price),
                "target_price": float(target_price),
                "best_hour_utc": int(best_hour),
                "best_day_of_week": int(best_day),  # 0=Monday, 6=Sunday
                "hourly_averages": hourly_avg.to_dict(),
                "daily_averages": daily_avg.to_dict(),
                "recent_trend": float(recent_trend),
                "recommendation": "wait" if current_price > target_price else "execute_now"
            }
            
            # Add time estimates
            if current_price > target_price:
                price_diff = (current_price - target_price) / current_price
                estimated_wait_hours = int(price_diff * 24)  # Rough estimate
                prediction["estimated_wait_hours"] = min(estimated_wait_hours, 48)
            else:
                prediction["estimated_wait_hours"] = 0
            
            return prediction
            
        except Exception as e:
            return {"error": str(e)}
    
    @staticmethod
    def calculate_network_efficiency(network_stats: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate network efficiency metrics"""
        try:
            if "error" in network_stats:
                return network_stats
            
            gas_used = network_stats.get("gas_used", 0)
            gas_limit = network_stats.get("gas_limit", 1)
            
            utilization = (gas_used / gas_limit) * 100 if gas_limit > 0 else 0
            
            # Efficiency scoring
            if utilization > 95:
                efficiency_score = "Poor"
                congestion_level = "Severe"
            elif utilization > 80:
                efficiency_score = "Fair"
                congestion_level = "High"
            elif utilization > 60:
                efficiency_score = "Good"
                congestion_level = "Moderate"
            elif utilization > 30:
                efficiency_score = "Very Good"
                congestion_level = "Low"
            else:
                efficiency_score = "Excellent"
                congestion_level = "Very Low"
            
            return {
                "network": network_stats.get("network", "Unknown"),
                "utilization_percentage": float(utilization),
                "efficiency_score": efficiency_score,
                "congestion_level": congestion_level,
                "gas_used": int(gas_used),
                "gas_limit": int(gas_limit),
                "available_capacity": int(gas_limit - gas_used),
                "latest_block": network_stats.get("latest_block", 0)
            }
            
        except Exception as e:
            return {"error": str(e)}
    
    @staticmethod
    def compare_networks(network_data: Dict[str, Any]) -> Dict[str, Any]:
        """Compare efficiency and costs across networks"""
        try:
            comparison = {
                "networks": [],
                "cheapest_network": None,
                "most_efficient_network": None,
                "recommendations": []
            }
            
            costs = {}
            efficiencies = {}
            
            for network, data in network_data.items():
                if "error" not in data:
                    # Calculate standard transaction cost (21000 gas)
                    gas_price = data.get("standard_gas_price", data.get("gas_price_gwei", 20))
                    cost = CalculationEngine.calculate_transaction_cost(21000, gas_price, network)
                    
                    if "error" not in cost:
                        costs[network] = cost["cost_usd"]
                        
                    # Get efficiency
                    if "network_utilization" in data:
                        efficiencies[network] = 100 - data["network_utilization"]  # Lower utilization = higher efficiency
                    
                    comparison["networks"].append({
                        "network": network,
                        "gas_price_gwei": gas_price,
                        "transaction_cost_usd": cost.get("cost_usd", 0),
                        "utilization": data.get("network_utilization", 0),
                        "efficiency_score": 100 - data.get("network_utilization", 0)
                    })
            
            # Find cheapest and most efficient
            if costs:
                comparison["cheapest_network"] = min(costs, key=costs.get)
            if efficiencies:
                comparison["most_efficient_network"] = max(efficiencies, key=efficiencies.get)
            
            # Generate recommendations
            if comparison["cheapest_network"] and comparison["most_efficient_network"]:
                if comparison["cheapest_network"] == comparison["most_efficient_network"]:
                    comparison["recommendations"].append(f"Use {comparison['cheapest_network']} for optimal cost and efficiency")
                else:
                    comparison["recommendations"].append(f"Use {comparison['cheapest_network']} for lowest cost")
                    comparison["recommendations"].append(f"Use {comparison['most_efficient_network']} for best efficiency")
            
            return comparison
            
        except Exception as e:
            return {"error": str(e)}
