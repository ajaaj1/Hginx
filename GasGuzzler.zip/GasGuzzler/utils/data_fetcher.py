"""
Data fetcher for blockchain analytics
"""
import requests
import pandas as pd
from datetime import datetime, timedelta
import time
import logging
import random
from typing import Dict, List, Optional, Any
from utils.blockchain_utils import BlockchainUtils
import threading
import asyncio

class DataFetcher:
    """Handles data fetching and caching for blockchain analytics"""
    
    def __init__(self):
        self.blockchain_utils = BlockchainUtils()
        self.cache = {}
        self.cache_timestamps = {}
        self.cache_duration = 30
        
        self.gas_price_history = {}
        self._initialize_history()
        
    def _initialize_history(self):
        """Initialize with some historical data"""
        networks = ["Ethereum", "Polygon", "BSC"]
        base_prices = {"Ethereum": 25, "Polygon": 50, "BSC": 5}
        
        for network in networks:
            self.gas_price_history[network] = []
            base_price = base_prices.get(network, 20)
            
            for i in range(50):
                timestamp = datetime.now() - timedelta(minutes=30 * (50 - i))
                variance = random.uniform(0.7, 1.3)
                price = base_price * variance
                
                self.gas_price_history[network].append({
                    'timestamp': timestamp,
                    'price': price
                })
        
    def _is_cache_valid(self, key: str) -> bool:
        """Check if cached data is still valid"""
        if key not in self.cache_timestamps:
            return False
        return time.time() - self.cache_timestamps[key] < self.cache_duration
    
    def _get_from_cache(self, key: str) -> Optional[Any]:
        """Get data from cache if valid"""
        if self._is_cache_valid(key):
            return self.cache.get(key)
        return None
    
    def _set_cache(self, key: str, data: Any):
        """Set data in cache"""
        self.cache[key] = data
        self.cache_timestamps[key] = time.time()
    
    def get_current_gas_prices(self, networks: List[str]) -> Dict[str, Any]:
        """Get current gas prices for specified networks"""
        cache_key = f"gas_prices_{'-'.join(sorted(networks))}"
        cached_data = self._get_from_cache(cache_key)
        
        if cached_data:
            return cached_data
        
        gas_prices = {}
        
        for network in networks:
            try:
                price_data = self.blockchain_utils.get_current_gas_price(network)
                if price_data:
                    gas_prices[network] = price_data
                    
                    if network not in self.gas_price_history:
                        self.gas_price_history[network] = []
                    
                    self.gas_price_history[network].append({
                        'timestamp': datetime.now(),
                        'price': price_data.get('standard_gas_price', price_data.get('gas_price_gwei', 0))
                    })
                    
                    if len(self.gas_price_history[network]) > 200:
                        self.gas_price_history[network] = self.gas_price_history[network][-200:]
                        
            except Exception as e:
                logging.error(f"Error fetching gas price for {network}: {e}")
                gas_prices[network] = self._get_fallback_gas_price(network)
        
        self._set_cache(cache_key, gas_prices)
        return gas_prices
    
    def _get_fallback_gas_price(self, network: str) -> Dict[str, Any]:
        """Get fallback gas prices"""
        base_prices = {"Ethereum": 25, "Polygon": 50, "BSC": 5}
        base = base_prices.get(network, 20)
        variance = random.uniform(0.8, 1.2)
        price = base * variance
        
        return {
            "network": network,
            "safe_gas_price": price * 0.8,
            "standard_gas_price": price,
            "fast_gas_price": price * 1.3,
            "gas_price_gwei": price,
            "timestamp": int(time.time()),
            "fallback": True
        }
    
    def get_gas_price_history(self, network: str, hours: int = 24) -> pd.DataFrame:
        """Get historical gas price data"""
        if network not in self.gas_price_history:
            return pd.DataFrame(columns=['timestamp', 'price'])
        
        cutoff_time = datetime.now() - timedelta(hours=hours)
        filtered_data = [
            entry for entry in self.gas_price_history[network]
            if entry['timestamp'] > cutoff_time
        ]
        
        if not filtered_data:
            return pd.DataFrame(columns=['timestamp', 'price'])
        
        df = pd.DataFrame(filtered_data)
        return df
    
    def get_network_statistics(self, networks: List[str]) -> Dict[str, Any]:
        """Get network statistics for specified networks"""
        cache_key = f"network_stats_{'-'.join(sorted(networks))}"
        cached_data = self._get_from_cache(cache_key)
        
        if cached_data:
            return cached_data
        
        network_stats = {}
        
        for network in networks:
            try:
                stats = self.blockchain_utils.get_network_stats(network)
                if stats:
                    network_stats[network] = stats
            except Exception as e:
                logging.error(f"Error fetching stats for {network}: {e}")
                network_stats[network] = self._get_fallback_network_stats(network)
        
        self._set_cache(cache_key, network_stats)
        return network_stats
    
    def _get_fallback_network_stats(self, network: str) -> Dict[str, Any]:
        """Get fallback network statistics"""
        block_bases = {"Ethereum": 19000000, "Polygon": 55000000, "BSC": 38000000}
        gas_limits = {"Ethereum": 30000000, "Polygon": 30000000, "BSC": 140000000}
        
        base_block = block_bases.get(network, 19000000)
        gas_limit = gas_limits.get(network, 30000000)
        utilization = random.uniform(40, 85)
        gas_used = int(gas_limit * (utilization / 100))
        
        return {
            "network": network,
            "latest_block": base_block + random.randint(0, 100000),
            "block_time": int(time.time()),
            "gas_limit": gas_limit,
            "gas_used": gas_used,
            "network_utilization": utilization,
            "fallback": True
        }
    
    def search_transaction(self, tx_hash: str, networks: List[str]) -> Optional[Dict[str, Any]]:
        """Search for transaction across networks"""
        for network in networks:
            try:
                tx_data = self.blockchain_utils.get_transaction_details(network, tx_hash)
                if tx_data:
                    return tx_data
            except Exception as e:
                logging.error(f"Error searching transaction in {network}: {e}")
        
        return None
    
    def calculate_optimal_gas_price(self, network: str, speed: str = "standard") -> Dict[str, Any]:
        """Calculate optimal gas price based on network conditions"""
        try:
            current_prices = self.get_current_gas_prices([network])
            network_stats = self.get_network_statistics([network])
            
            if network not in current_prices or network not in network_stats:
                return {"error": "Failed to fetch network data"}
            
            gas_data = current_prices[network]
            stats = network_stats[network]
            
            recommendations = {
                "network": network,
                "current_prices": gas_data,
                "network_utilization": stats.get("network_utilization", 50),
                "recommendations": {}
            }
            
            utilization = stats.get("network_utilization", 50)
            base_price = gas_data.get("standard_gas_price", gas_data.get("gas_price_gwei", 20))
            
            if utilization > 90:
                recommendations["recommendations"] = {
                    "slow": base_price * 0.8,
                    "standard": base_price * 1.2,
                    "fast": base_price * 1.5,
                    "status": "high_congestion",
                    "wait_time_estimates": {"slow": "10-20 min", "standard": "2-5 min", "fast": "< 2 min"}
                }
            elif utilization > 70:
                recommendations["recommendations"] = {
                    "slow": base_price * 0.9,
                    "standard": base_price,
                    "fast": base_price * 1.2,
                    "status": "medium_congestion",
                    "wait_time_estimates": {"slow": "5-10 min", "standard": "1-3 min", "fast": "< 1 min"}
                }
            else:
                recommendations["recommendations"] = {
                    "slow": base_price * 0.7,
                    "standard": base_price * 0.9,
                    "fast": base_price,
                    "status": "low_congestion",
                    "wait_time_estimates": {"slow": "2-5 min", "standard": "< 2 min", "fast": "< 1 min"}
                }
            
            return recommendations
            
        except Exception as e:
            logging.error(f"Error calculating optimal gas price: {e}")
            return {"error": str(e)}
    
    def get_mempool_data(self, network: str) -> Dict[str, Any]:
        """Get mempool statistics"""
        try:
            network_stats = self.get_network_statistics([network])
            if network not in network_stats:
                return self._get_simulated_mempool_data(network)
            
            stats = network_stats[network]
            utilization = stats.get("network_utilization", 50)
            
            pending_base = {"Ethereum": 150, "Polygon": 80, "BSC": 60}
            base = pending_base.get(network, 100)
            pending_transactions = int(base * (utilization / 50) * random.uniform(0.8, 1.2))
            
            gas_prices = self.get_current_gas_prices([network])
            avg_gas = gas_prices.get(network, {}).get("standard_gas_price", 20)
            
            if utilization > 80:
                congestion = "High"
                clear_time = f"{int(utilization / 8)} minutes"
            elif utilization > 50:
                congestion = "Medium"
                clear_time = f"{int(utilization / 15)} minutes"
            else:
                congestion = "Low"
                clear_time = "< 2 minutes"
            
            return {
                "network": network,
                "pending_transactions": pending_transactions,
                "average_gas_price": avg_gas,
                "congestion_level": congestion,
                "estimated_clear_time": clear_time
            }
            
        except Exception as e:
            logging.error(f"Error getting mempool data: {e}")
            return self._get_simulated_mempool_data(network)
    
    def _get_simulated_mempool_data(self, network: str) -> Dict[str, Any]:
        """Get simulated mempool data"""
        pending_base = {"Ethereum": 150, "Polygon": 80, "BSC": 60}
        gas_base = {"Ethereum": 25, "Polygon": 50, "BSC": 5}
        
        pending = int(pending_base.get(network, 100) * random.uniform(0.5, 1.5))
        gas_price = gas_base.get(network, 20) * random.uniform(0.8, 1.2)
        
        if pending > 200:
            congestion = "High"
            clear_time = f"{int(pending / 20)} minutes"
        elif pending > 100:
            congestion = "Medium"
            clear_time = f"{int(pending / 40)} minutes"
        else:
            congestion = "Low"
            clear_time = "< 2 minutes"
        
        return {
            "network": network,
            "pending_transactions": pending,
            "average_gas_price": gas_price,
            "congestion_level": congestion,
            "estimated_clear_time": clear_time
        }
