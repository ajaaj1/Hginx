"""
Network analysis component
"""
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime, timedelta
from utils.calculations import CalculationEngine

def render_network_analyzer(data_fetcher, selected_networks):
    """Render the network analysis page"""
    
    st.header("🌐 Network Analyzer")
    
    if not selected_networks:
        st.warning("Please select at least one network from the sidebar.")
        return
    
    # Network overview
    st.subheader("📈 Network Performance Overview")
    
    with st.spinner("Analyzing network performance..."):
        network_stats = data_fetcher.get_network_statistics(selected_networks)
        gas_prices = data_fetcher.get_current_gas_prices(selected_networks)
    
    # Create network performance cards
    for network in selected_networks:
        if network in network_stats and "error" not in network_stats[network]:
            stats = network_stats[network]
            efficiency_data = CalculationEngine.calculate_network_efficiency(stats)
            
            with st.container():
                st.markdown(f"### {network} Network Status")
                
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    if "latest_block" in stats:
                        st.metric("Latest Block", f"{stats['latest_block']:,}")
                    
                    if "gas_limit" in stats:
                        st.metric("Block Gas Limit", f"{stats['gas_limit']:,}")
                
                with col2:
                    if "gas_used" in stats:
                        st.metric("Gas Used", f"{stats['gas_used']:,}")
                    
                    if "available_capacity" in efficiency_data:
                        st.metric("Available Capacity", f"{efficiency_data['available_capacity']:,}")
                
                with col3:
                    if "utilization_percentage" in efficiency_data:
                        utilization = efficiency_data['utilization_percentage']
                        color = "normal" if utilization < 70 else "inverse"
                        st.metric("Network Utilization", f"{utilization:.1f}%", 
                                delta=None, delta_color=color)
                    
                    if "efficiency_score" in efficiency_data:
                        st.metric("Efficiency Score", efficiency_data['efficiency_score'])
                
                with col4:
                    if "congestion_level" in efficiency_data:
                        congestion = efficiency_data['congestion_level']
                        congestion_colors = {
                            'Very Low': '🟢',
                            'Low': '🟢',
                            'Moderate': '🟡',
                            'High': '🟠',
                            'Severe': '🔴'
                        }
                        st.metric("Congestion Level", 
                                f"{congestion_colors.get(congestion, '⚪')} {congestion}")
                    
                    # Network health score
                    if "utilization_percentage" in efficiency_data:
                        health_score = max(0, 100 - efficiency_data['utilization_percentage'])
                        st.metric("Health Score", f"{health_score:.0f}/100")
                
                st.divider()
        else:
            st.error(f"❌ Failed to load {network} statistics")
    
    # Network comparison
    if len(selected_networks) > 1:
        st.subheader("⚖️ Network Comparison Analysis")
        
        # Prepare comparison data
        comparison_data = []
        
        for network in selected_networks:
            if (network in network_stats and "error" not in network_stats[network] and
                network in gas_prices and "error" not in gas_prices[network]):
                
                stats = network_stats[network]
                gas_data = gas_prices[network]
                efficiency_data = CalculationEngine.calculate_network_efficiency(stats)
                
                current_gas_price = gas_data.get('standard_gas_price', gas_data.get('gas_price_gwei', 0))
                
                # Calculate transaction costs for standard transaction (21k gas)
                cost_data = CalculationEngine.calculate_transaction_cost(21000, current_gas_price, network)
                
                comparison_data.append({
                    'Network': network,
                    'Gas Price (Gwei)': current_gas_price,
                    'Utilization (%)': efficiency_data.get('utilization_percentage', 0),
                    'Efficiency Score': efficiency_data.get('efficiency_score', 'N/A'),
                    'Tx Cost (USD)': cost_data.get('cost_usd', 0) if 'error' not in cost_data else 0,
                    'Latest Block': stats.get('latest_block', 0),
                    'Congestion': efficiency_data.get('congestion_level', 'Unknown')
                })
        
        if comparison_data:
            df_comparison = pd.DataFrame(comparison_data)
            
            # Display comparison table
            st.subheader("📊 Comparison Table")
            st.dataframe(df_comparison, use_container_width=True, hide_index=True)
            
            # Create comparison charts
            chart_col1, chart_col2 = st.columns(2)
            
            with chart_col1:
                # Gas price vs utilization scatter
                fig = go.Figure()
                
                colors = px.colors.qualitative.Set1[:len(df_comparison)]
                
                fig.add_trace(go.Scatter(
                    x=df_comparison['Utilization (%)'],
                    y=df_comparison['Gas Price (Gwei)'],
                    mode='markers+text',
                    text=df_comparison['Network'],
                    textposition='top center',
                    marker=dict(size=15, color=colors),
                    name='Networks'
                ))
                
                fig.update_layout(
                    title="Gas Price vs Network Utilization",
                    xaxis_title="Network Utilization (%)",
                    yaxis_title="Gas Price (Gwei)",
                    height=400,
                    showlegend=False
                )
                
                st.plotly_chart(fig, use_container_width=True)
            
            with chart_col2:
                # Transaction cost comparison
                fig = go.Figure()
                
                fig.add_trace(go.Bar(
                    x=df_comparison['Network'],
                    y=df_comparison['Tx Cost (USD)'],
                    marker_color=colors,
                    text=[f"${cost:.3f}" for cost in df_comparison['Tx Cost (USD)']],
                    textposition='auto'
                ))
                
                fig.update_layout(
                    title="Transaction Cost Comparison (21k gas)",
                    xaxis_title="Network",
                    yaxis_title="Cost (USD)",
                    height=400
                )
                
                st.plotly_chart(fig, use_container_width=True)
            
            # Network recommendations
            st.subheader("💡 Network Recommendations")
            
            # Find best networks for different use cases
            cheapest_network = df_comparison.loc[df_comparison['Tx Cost (USD)'].idxmin()]
            fastest_network = df_comparison.loc[df_comparison['Utilization (%)'].idxmin()]
            
            rec_col1, rec_col2 = st.columns(2)
            
            with rec_col1:
                st.success(f"💰 **Cheapest for transactions**: {cheapest_network['Network']}")
                st.write(f"Cost: ${cheapest_network['Tx Cost (USD)']:.4f} per transaction")
                
            with rec_col2:
                st.success(f"⚡ **Fastest confirmation**: {fastest_network['Network']}")
                st.write(f"Utilization: {fastest_network['Utilization (%)']:.1f}%")
    
    # Historical network analysis
    st.subheader("📈 Historical Network Analysis")
    
    analysis_network = st.selectbox("Select Network for Historical Analysis", selected_networks)
    
    # Time range for historical analysis
    hist_time_range = st.selectbox("Historical Time Range", 
                                  ["24 Hours", "7 Days", "30 Days"], 
                                  index=1)
    
    hours_map = {"24 Hours": 24, "7 Days": 168, "30 Days": 720}
    hist_hours = hours_map[hist_time_range]
    
    history_df = data_fetcher.get_gas_price_history(analysis_network, hours=hist_hours)
    
    if not history_df.empty:
        # Perform trend analysis
        trend_analysis = CalculationEngine.analyze_gas_trends(history_df)
        
        if "error" not in trend_analysis:
            # Display trend metrics
            st.subheader(f"📊 {analysis_network} - {hist_time_range} Analysis")
            
            trend_col1, trend_col2, trend_col3, trend_col4 = st.columns(4)
            
            with trend_col1:
                st.metric("Average Gas Price", f"{trend_analysis['average_price']:.2f} Gwei")
                st.metric("Median Gas Price", f"{trend_analysis['median_price']:.2f} Gwei")
            
            with trend_col2:
                st.metric("Minimum Price", f"{trend_analysis['min_price']:.2f} Gwei")
                st.metric("Maximum Price", f"{trend_analysis['max_price']:.2f} Gwei")
            
            with trend_col3:
                st.metric("Price Volatility", f"{trend_analysis['volatility']:.1f}%")
                st.metric("Standard Deviation", f"{trend_analysis['std_deviation']:.2f}")
            
            with trend_col4:
                trend_emoji = "📈" if trend_analysis['trend_direction'] == "increasing" else "📉" if trend_analysis['trend_direction'] == "decreasing" else "➡️"
                st.metric("Price Trend", f"{trend_emoji} {trend_analysis['trend_direction'].title()}")
                change_color = "normal" if abs(trend_analysis['price_change_24h']) < 5 else "inverse"
                st.metric("Price Change", f"{trend_analysis['price_change_24h']:+.1f}%", 
                         delta_color=change_color)
            
            # Historical price chart with analysis
            fig = go.Figure()
            
            # Price line
            fig.add_trace(go.Scatter(
                x=history_df['timestamp'],
                y=history_df['price'],
                mode='lines',
                name='Gas Price',
                line=dict(width=2, color='#1f77b4')
            ))
            
            # Add moving average
            if len(history_df) >= 20:
                history_df['ma20'] = history_df['price'].rolling(window=20, center=True).mean()
                fig.add_trace(go.Scatter(
                    x=history_df['timestamp'],
                    y=history_df['ma20'],
                    mode='lines',
                    name='20-Period Moving Average',
                    line=dict(width=2, color='red', dash='dash')
                ))
            
            # Add trend lines
            fig.add_hline(y=trend_analysis['average_price'], 
                         line_dash="dot", 
                         line_color="green",
                         annotation_text=f"Average: {trend_analysis['average_price']:.1f}")
            
            fig.update_layout(
                title=f"{analysis_network} Gas Price Analysis ({hist_time_range})",
                xaxis_title="Time",
                yaxis_title="Gas Price (Gwei)",
                height=500,
                hovermode='x unified'
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Optimal timing predictions
            if hist_hours >= 168:  # Only for 7+ days of data
                st.subheader("🎯 Optimal Transaction Timing")
                
                timing_prediction = CalculationEngine.predict_optimal_timing(history_df)
                
                if "error" not in timing_prediction:
                    timing_col1, timing_col2 = st.columns(2)
                    
                    with timing_col1:
                        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
                        best_day = days[timing_prediction['best_day_of_week']]
                        
                        st.success(f"🗓️ **Best Day**: {best_day}")
                        st.success(f"⏰ **Best Hour (UTC)**: {timing_prediction['best_hour_utc']:02d}:00")
                        
                    with timing_col2:
                        if timing_prediction.get('hourly_averages'):
                            min_hour_price = min(timing_prediction['hourly_averages'].values())
                            max_hour_price = max(timing_prediction['hourly_averages'].values())
                            savings_potential = ((max_hour_price - min_hour_price) / max_hour_price) * 100
                            
                            st.info(f"💰 **Potential Savings**: {savings_potential:.1f}%")
                            st.info(f"📊 **Price Range**: {min_hour_price:.1f} - {max_hour_price:.1f} Gwei")
    
    else:
        st.info(f"No historical data available for {analysis_network}")
    
    # Network health monitoring
    st.subheader("🏥 Network Health Monitoring")
    
    health_col1, health_col2 = st.columns(2)
    
    with health_col1:
        st.markdown("**Key Health Indicators:**")
        
        for network in selected_networks:
            if network in network_stats and "error" not in network_stats[network]:
                stats = network_stats[network]
                efficiency_data = CalculationEngine.calculate_network_efficiency(stats)
                
                utilization = efficiency_data.get('utilization_percentage', 0)
                health_score = max(0, 100 - utilization)
                
                # Health status
                if health_score >= 80:
                    status = "🟢 Excellent"
                elif health_score >= 60:
                    status = "🟡 Good" 
                elif health_score >= 40:
                    status = "🟠 Fair"
                else:
                    status = "🔴 Poor"
                
                st.write(f"**{network}**: {status} (Score: {health_score:.0f}/100)")
    
    with health_col2:
        st.markdown("**Health Score Factors:**")
        st.write("- **Network Utilization** (Lower is better)")
        st.write("- **Gas Price Stability** (Less volatile is better)")  
        st.write("- **Block Consistency** (Regular block times)")
        st.write("- **Mempool Size** (Smaller backlog is better)")
        
    # Alert system setup
    with st.expander("🚨 Set Up Network Alerts"):
        st.markdown("Configure alerts for network conditions:")
        
        alert_network = st.selectbox("Alert Network", selected_networks, key="alert_net")
        
        col1, col2 = st.columns(2)
        with col1:
            max_gas_price = st.number_input("Alert when gas price exceeds (Gwei)", 
                                          min_value=1.0, max_value=500.0, value=50.0)
            max_utilization = st.number_input("Alert when utilization exceeds (%)", 
                                            min_value=1, max_value=100, value=90)
        
        with col2:
            min_gas_price = st.number_input("Alert when gas price drops below (Gwei)", 
                                          min_value=1.0, max_value=200.0, value=10.0)
            
        if st.button("Check Current Conditions"):
            current_gas = gas_prices.get(alert_network, {}).get('standard_gas_price', 0)
            current_util = network_stats.get(alert_network, {}).get('network_utilization', 0)
            
            alerts = []
            
            if current_gas > max_gas_price:
                alerts.append(f"🔴 High gas price alert: {current_gas:.1f} Gwei (threshold: {max_gas_price:.1f})")
            
            if current_gas < min_gas_price:
                alerts.append(f"🟢 Low gas price opportunity: {current_gas:.1f} Gwei (threshold: {min_gas_price:.1f})")
            
            if current_util > max_utilization:
                alerts.append(f"🟠 High network utilization: {current_util:.1f}% (threshold: {max_utilization}%)")
            
            if alerts:
                for alert in alerts:
                    st.warning(alert)
            else:
                st.success("✅ All conditions are within normal ranges")
