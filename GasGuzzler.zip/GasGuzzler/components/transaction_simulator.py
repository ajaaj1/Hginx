"""
Transaction simulator component for multi-crypto support
"""
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime
import time

def get_simulator():
    """Get or create the transaction simulator instance"""
    if 'tx_simulator' not in st.session_state:
        from utils.transaction_simulator import TransactionSimulator
        st.session_state.tx_simulator = TransactionSimulator()
    return st.session_state.tx_simulator

def render_transaction_simulator():
    """Render the transaction simulator page"""
    
    st.header("🔄 Crypto Transaction Simulator")
    st.markdown("**Simulate cryptocurrency transactions with realistic data across major networks**")
    
    simulator = get_simulator()
    
    simulator.simulate_confirmation_progress()
    
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "💳 Create Transaction", 
        "👛 Wallet Manager", 
        "📜 Transaction History",
        "💀 Exploit",
        "📊 Statistics"
    ])
    
    with tab1:
        render_create_transaction(simulator)
    
    with tab2:
        render_wallet_manager(simulator)
    
    with tab3:
        render_transaction_history(simulator)
    
    with tab4:
        render_confirmation_manager(simulator)
    
    with tab5:
        render_statistics(simulator)

def render_create_transaction(simulator):
    """Render the create transaction section"""
    st.subheader("📤 Create New Transaction")
    
    prices = simulator.get_all_prices()
    target_wallets = simulator.get_all_target_wallets()
    
    st.markdown("### 💰 Target Wallet Balances")
    balance_cols = st.columns(5)
    for i, (crypto, wallet) in enumerate(target_wallets.items()):
        with balance_cols[i % 5]:
            price = prices.get(crypto, {}).get("price_usd", simulator.BASE_PRICES.get(crypto, 100.0))
            balance_usd = wallet["balance"] * price
            st.metric(
                label=f"{wallet['symbol']}",
                value=f"${balance_usd:,.0f}",
                delta=f"{wallet['balance']:.4f}"
            )
    
    st.divider()
    
    col1, col2 = st.columns(2)
    
    with col1:
        crypto = st.selectbox(
            "Select Cryptocurrency",
            list(simulator.SUPPORTED_CRYPTOS.keys()),
            format_func=lambda x: f"{x} - {simulator.SUPPORTED_CRYPTOS[x]['name']}"
        )
        
        config = simulator.SUPPORTED_CRYPTOS[crypto]
        target_wallet = target_wallets.get(crypto, {})
        price = prices.get(crypto, {}).get("price_usd", simulator.BASE_PRICES.get(crypto, 100.0))
        balance = target_wallet.get("balance", 0)
        balance_usd = balance * price
        
        st.success(f"**{config['name']}** | Available: **{balance:.8f} {config['symbol']}** (${balance_usd:,.2f})")
        st.caption(f"Block Time: {config['block_time']}s | Confirmations Required: {config['confirmations_required']}")
        
        st.markdown("**From: Target Wallet**")
        from_address = target_wallet.get("address", "")
        st.code(f"{from_address[:20]}...{from_address[-10:]}" if from_address else "No wallet loaded")
    
    with col2:
        to_address = st.text_input("To Address", placeholder=f"{config['address_prefix']}...")
        
        max_amount = max(0, balance - config['avg_fee'])
        
        amount = st.number_input(
            f"Amount ({config['symbol']})",
            min_value=0.0,
            max_value=max_amount,
            value=min(0.01, max_amount) if max_amount > 0 else 0.0,
            step=0.001,
            format="%.8f"
        )
        
        current_price = prices.get(crypto, {}).get("price_usd", 0)
        usd_value = amount * current_price
        st.caption(f"≈ ${usd_value:,.2f} USD")
        
        remaining = balance - amount - config['avg_fee']
        if remaining >= 0:
            st.info(f"Remaining after tx: ~{remaining:.8f} {config['symbol']} (${remaining * price:,.2f})")
        else:
            st.warning(f"Insufficient balance for this amount + fees")
    
    col3, col4 = st.columns(2)
    
    with col3:
        use_custom_fee = st.checkbox("Custom Fee")
        if use_custom_fee:
            fee = st.number_input(
                f"Transaction Fee ({config['symbol']})",
                min_value=0.0,
                max_value=1.0,
                value=config['avg_fee'],
                step=0.0001,
                format="%.8f"
            )
        else:
            fee = None
            st.caption(f"Default fee: ~{config['avg_fee']} {config['symbol']}")
    
    with col4:
        memo = st.text_input("Memo / Note (optional)", placeholder="Payment for services...")
    
    if st.button("🚀 Create Transaction", type="primary", use_container_width=True):
        if not to_address:
            st.error("Please enter a To address")
        elif amount <= 0:
            st.error("Please enter a valid amount")
        elif from_address == to_address:
            st.error("From and To addresses cannot be the same")
        else:
            with st.spinner("Creating transaction..."):
                time.sleep(0.5)
                tx = simulator.create_transaction(
                    crypto=crypto,
                    from_address=from_address,
                    to_address=to_address,
                    amount=amount,
                    fee=fee,
                    memo=memo,
                    use_target_wallet=True
                )
                
                if "error" not in tx:
                    st.success("✅ Transaction created successfully!")
                    
                    st.markdown("### Transaction Details")
                    
                    detail_col1, detail_col2 = st.columns(2)
                    
                    with detail_col1:
                        st.code(f"Transaction ID: {tx['id']}")
                        st.code(f"Hash: {tx['hash']}")
                        st.write(f"**Status**: 🟡 {tx['status'].upper()}")
                        st.write(f"**Confirmations**: {tx['confirmations']} / {tx['confirmations_required']}")
                    
                    with detail_col2:
                        st.write(f"**Amount**: {tx['amount']} {tx['symbol']} (${tx['amount_usd']:,.2f})")
                        st.write(f"**Fee**: {tx['fee']:.8f} {tx['symbol']} (${tx['fee_usd']:,.2f})")
                        st.write(f"**Total**: {tx['total']:.8f} {tx['symbol']} (${tx['total_usd']:,.2f})")
                        st.write(f"**Network**: {tx['network']}")
                    
                    st.markdown("### 💰 Balance Update")
                    bal_col1, bal_col2 = st.columns(2)
                    with bal_col1:
                        st.metric("Balance Before", f"{tx['balance_before']:.8f} {tx['symbol']}", delta=f"${tx['balance_before_usd']:,.2f}")
                    with bal_col2:
                        change = tx['balance_after'] - tx['balance_before']
                        st.metric("Balance After", f"{tx['balance_after']:.8f} {tx['symbol']}", delta=f"{change:+.8f}", delta_color="inverse")
                else:
                    st.error(f"Failed to create transaction: {tx['error']}")

def render_wallet_manager(simulator):
    """Render the wallet manager section with target wallets"""
    st.subheader("👛 Target Wallet Manager")
    
    st.markdown("### 🎯 Target Wallets (Pre-loaded with $15,000+ USD)")
    st.markdown("Each cryptocurrency has a target wallet with funds ready for transactions.")
    
    target_wallets = simulator.get_all_target_wallets()
    prices = simulator.get_all_prices()
    
    wallet_cols = st.columns(2)
    
    for idx, (crypto, wallet) in enumerate(target_wallets.items()):
        with wallet_cols[idx % 2]:
            price = prices.get(crypto, {}).get("price_usd", simulator.BASE_PRICES.get(crypto, 100.0))
            balance_usd = wallet["balance"] * price
            initial_balance_usd = wallet["initial_balance"] * price
            
            balance_change = wallet["balance"] - wallet["initial_balance"]
            change_color = "green" if balance_change >= 0 else "red"
            
            with st.container():
                st.markdown(f"#### 💰 {wallet['name']} ({wallet['symbol']})")
                
                col_a, col_b = st.columns(2)
                
                with col_a:
                    st.metric(
                        label="Balance",
                        value=f"{wallet['balance']:.8f} {wallet['symbol']}",
                        delta=f"{balance_change:+.8f}" if balance_change != 0 else None,
                        delta_color="inverse"
                    )
                
                with col_b:
                    st.metric(
                        label="USD Value",
                        value=f"${balance_usd:,.2f}",
                        delta=f"${balance_change * price:+,.2f}" if balance_change != 0 else None,
                        delta_color="inverse"
                    )
                
                with st.expander(f"🔍 View Wallet Details"):
                    st.code(f"Address: {wallet['address']}", language=None)
                    st.write(f"**Initial Balance**: {wallet['initial_balance']:.8f} {wallet['symbol']} (${initial_balance_usd:,.2f})")
                    st.write(f"**Current Balance**: {wallet['balance']:.8f} {wallet['symbol']} (${balance_usd:,.2f})")
                    st.write(f"**Created**: {wallet['created_at'][:19]}")
                    
                    with st.popover("🔐 View Private Key"):
                        st.warning("⚠️ Never share your private key!")
                        st.code(wallet['private_key'])
                
                st.divider()
    
    st.markdown("### 🔄 Load Target Wallet")
    st.markdown("Reload a target wallet with fresh funds (resets balance to $15,000+ USD)")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        crypto = st.selectbox(
            "Select Cryptocurrency to Reload",
            list(simulator.SUPPORTED_CRYPTOS.keys()),
            format_func=lambda x: f"{x} - {simulator.SUPPORTED_CRYPTOS[x]['name']}",
            key="reload_wallet_crypto"
        )
    
    with col2:
        current_wallet = target_wallets.get(crypto, {})
        current_balance = current_wallet.get("balance", 0)
        price = prices.get(crypto, {}).get("price_usd", simulator.BASE_PRICES.get(crypto, 100.0))
        st.metric("Current Balance", f"${current_balance * price:,.2f}")
    
    if st.button("🎯 Load Target Wallet", type="primary", use_container_width=True):
        wallet = simulator.load_target_wallet(crypto)
        
        if "error" not in wallet:
            price = prices.get(crypto, {}).get("price_usd", simulator.BASE_PRICES.get(crypto, 100.0))
            balance_usd = wallet["balance"] * price
            st.success(f"✅ {crypto} target wallet loaded with {wallet['balance']:.8f} {wallet['symbol']} (${balance_usd:,.2f})!")
            st.rerun()
        else:
            st.error(wallet["error"])

def render_transaction_history(simulator):
    """Render the transaction history section"""
    st.subheader("📜 Transaction History")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        filter_crypto = st.selectbox(
            "Filter by Crypto",
            ["All"] + list(simulator.SUPPORTED_CRYPTOS.keys()),
            key="history_crypto_filter"
        )
    
    with col2:
        filter_status = st.selectbox(
            "Filter by Status",
            ["All", "pending", "confirming", "confirmed", "failed", "cancelled"],
            key="history_status_filter"
        )
    
    with col3:
        limit = st.number_input("Max Results", min_value=10, max_value=500, value=50, step=10)
    
    crypto_filter = filter_crypto if filter_crypto != "All" else None
    status_filter = filter_status if filter_status != "All" else None
    
    transactions = simulator.get_transactions(
        crypto=crypto_filter,
        status=status_filter,
        limit=limit
    )
    
    if st.button("🔄 Refresh", type="secondary"):
        simulator.simulate_confirmation_progress()
        st.rerun()
    
    if transactions:
        st.markdown(f"### Showing {len(transactions)} transactions")
        
        for tx in transactions:
            status_icons = {
                "pending": "🟡",
                "confirming": "🔵",
                "confirmed": "🟢",
                "failed": "🔴",
                "cancelled": "⚫"
            }
            
            status_icon = status_icons.get(tx["status"], "⚪")
            
            with st.expander(
                f"{status_icon} {tx['symbol']} | {tx['amount']:.8f} | {tx['status'].upper()} | {tx['id']}"
            ):
                col_a, col_b = st.columns(2)
                
                with col_a:
                    st.markdown("**Transaction Info**")
                    st.code(f"ID: {tx['id']}")
                    st.code(f"Hash: {tx['hash']}")
                    st.write(f"**Network**: {tx['network']}")
                    st.write(f"**Created**: {tx['created_at'][:19]}")
                    if tx['confirmed_at']:
                        st.write(f"**Confirmed**: {tx['confirmed_at'][:19]}")
                    st.write(f"**Last Updated**: {tx['updated_at'][:19]}")
                
                with col_b:
                    st.markdown("**Transfer Details**")
                    st.write(f"**From**: `{tx['from_address'][:20]}...`")
                    st.write(f"**To**: `{tx['to_address'][:20]}...`")
                    st.write(f"**Amount**: {tx['amount']:.8f} {tx['symbol']} (${tx.get('amount_usd', 0):,.2f})")
                    st.write(f"**Fee**: {tx['fee']:.8f} {tx['symbol']} (${tx.get('fee_usd', 0):,.2f})")
                    st.write(f"**Total**: {tx['total']:.8f} {tx['symbol']} (${tx.get('total_usd', 0):,.2f})")
                    if tx['memo']:
                        st.write(f"**Memo**: {tx['memo']}")
                
                st.divider()
                
                col_c, col_d = st.columns(2)
                
                with col_c:
                    st.markdown("**Confirmation Status**")
                    progress = min(tx['confirmations'] / tx['confirmations_required'], 1.0)
                    st.progress(progress, text=f"{tx['confirmations']} / {tx['confirmations_required']} confirmations")
                    st.write(f"**Status**: {status_icon} {tx['status'].upper()}")
                
                with col_d:
                    st.markdown("**Block Info**")
                    if tx['block_number']:
                        st.write(f"**Block Number**: {tx['block_number']:,}")
                        st.write(f"**Block Hash**: {tx['block_hash'][:20]}...")
                    else:
                        st.write("*Waiting for block inclusion...*")
                    
                    if tx.get('gas_limit'):
                        st.write(f"**Gas Limit**: {tx['gas_limit']:,}")
                        st.write(f"**Gas Price**: {tx['gas_price']:.2f} Gwei")
                
                if tx.get('balance_before') is not None and tx.get('balance_after') is not None:
                    st.divider()
                    st.markdown("**💰 Balance Change**")
                    bal_col1, bal_col2, bal_col3 = st.columns(3)
                    
                    with bal_col1:
                        st.metric(
                            "Before",
                            f"{tx['balance_before']:.8f}",
                            delta=f"${tx.get('balance_before_usd', 0):,.2f}"
                        )
                    
                    with bal_col2:
                        change = tx['balance_after'] - tx['balance_before']
                        st.metric(
                            "Change",
                            f"{change:+.8f}",
                            delta=f"-${tx.get('total_usd', 0):,.2f}",
                            delta_color="inverse"
                        )
                    
                    with bal_col3:
                        st.metric(
                            "After",
                            f"{tx['balance_after']:.8f}",
                            delta=f"${tx.get('balance_after_usd', 0):,.2f}"
                        )
    else:
        st.info("No transactions found. Create your first transaction in the Create Transaction tab!")
    
    if simulator.transactions:
        st.divider()
        if st.button("🗑️ Clear All Transactions", type="secondary"):
            simulator.clear_transactions()
            st.success("All transactions cleared")
            st.rerun()

def render_confirmation_manager(simulator):
    """Render the confirmation manager section"""
    st.subheader("💀 Exploit")
    st.markdown("**Manually adjust transaction confirmations and status**")
    
    pending_txs = simulator.get_pending_transactions()
    all_txs = simulator.get_transactions(limit=100)
    
    st.markdown("### Quick Actions")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("⚡ Simulate All Confirmations", use_container_width=True):
            simulator.simulate_confirmation_progress()
            st.success("Confirmations updated!")
            st.rerun()
    
    with col2:
        if st.button("✅ Confirm All Pending", use_container_width=True):
            for tx in pending_txs:
                simulator.update_confirmation(tx['id'], tx['confirmations_required'])
            st.success(f"Confirmed {len(pending_txs)} transactions!")
            st.rerun()
    
    with col3:
        pending_count = len(pending_txs)
        st.metric("Pending Transactions", pending_count)
    
    st.divider()
    
    st.markdown("### Edit Individual Transaction")
    
    if all_txs:
        tx_options = [f"{tx['id']} | {tx['symbol']} | {tx['status']}" for tx in all_txs]
        selected_tx_str = st.selectbox("Select Transaction", tx_options)
        
        if selected_tx_str:
            selected_idx = tx_options.index(selected_tx_str)
            selected_tx = all_txs[selected_idx]
            
            st.markdown(f"### Editing: {selected_tx['id']}")
            
            col_a, col_b = st.columns(2)
            
            with col_a:
                st.markdown("**Current Status**")
                st.write(f"**Status**: {selected_tx['status']}")
                st.write(f"**Confirmations**: {selected_tx['confirmations']} / {selected_tx['confirmations_required']}")
                
                progress = min(selected_tx['confirmations'] / selected_tx['confirmations_required'], 1.0)
                st.progress(progress)
            
            with col_b:
                st.markdown("**Modify Settings**")
                
                new_confirmations = st.number_input(
                    "Set Confirmations",
                    min_value=0,
                    max_value=selected_tx['confirmations_required'] + 10,
                    value=selected_tx['confirmations'],
                    key=f"conf_{selected_tx['id']}"
                )
                
                new_status = st.selectbox(
                    "Set Status",
                    ["pending", "confirming", "confirmed", "failed", "cancelled"],
                    index=["pending", "confirming", "confirmed", "failed", "cancelled"].index(selected_tx['status']) if selected_tx['status'] in ["pending", "confirming", "confirmed", "failed", "cancelled"] else 0,
                    key=f"status_{selected_tx['id']}"
                )
            
            col_c, col_d = st.columns(2)
            
            with col_c:
                if st.button("💾 Update Confirmations", type="primary", use_container_width=True):
                    result = simulator.update_confirmation(selected_tx['id'], new_confirmations)
                    if result:
                        st.success(f"Updated confirmations to {new_confirmations}")
                        st.rerun()
                    else:
                        st.error("Failed to update")
            
            with col_d:
                if st.button("📝 Update Status", type="secondary", use_container_width=True):
                    result = simulator.set_transaction_status(selected_tx['id'], new_status)
                    if result:
                        st.success(f"Updated status to {new_status}")
                        st.rerun()
                    else:
                        st.error("Failed to update")
            
            st.markdown("### Quick Confirmation Actions")
            
            quick_cols = st.columns(6)
            
            with quick_cols[0]:
                if st.button("0️⃣ Set 0"):
                    simulator.update_confirmation(selected_tx['id'], 0)
                    st.rerun()
            
            with quick_cols[1]:
                if st.button("1️⃣ Set 1"):
                    simulator.update_confirmation(selected_tx['id'], 1)
                    st.rerun()
            
            with quick_cols[2]:
                if st.button("2️⃣ Set 2"):
                    simulator.update_confirmation(selected_tx['id'], 2)
                    st.rerun()
            
            with quick_cols[3]:
                if st.button("3️⃣ Set 3"):
                    simulator.update_confirmation(selected_tx['id'], 3)
                    st.rerun()
            
            with quick_cols[4]:
                if st.button("6️⃣ Set 6"):
                    simulator.update_confirmation(selected_tx['id'], 6)
                    st.rerun()
            
            with quick_cols[5]:
                if st.button("✅ Full"):
                    simulator.update_confirmation(selected_tx['id'], selected_tx['confirmations_required'])
                    st.rerun()
    else:
        st.info("No transactions available. Create transactions first!")

def render_statistics(simulator):
    """Render the statistics section"""
    st.subheader("📊 Transaction Statistics")
    
    stats = simulator.get_transaction_stats()
    prices = simulator.get_all_prices()
    
    st.markdown("### Overview")
    
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        st.metric("Total Transactions", stats['total_transactions'])
    
    with col2:
        st.metric("Pending", stats['pending'], delta_color="off")
    
    with col3:
        st.metric("Confirming", stats['confirming'], delta_color="off")
    
    with col4:
        st.metric("Confirmed", stats['confirmed'])
    
    with col5:
        st.metric("Failed", stats['failed'], delta_color="inverse")
    
    if stats['by_crypto']:
        st.markdown("### Transactions by Cryptocurrency")
        
        crypto_data = []
        for crypto, data in stats['by_crypto'].items():
            price = prices.get(crypto, {}).get('price_usd', 0)
            volume_usd = data['volume'] * price
            crypto_data.append({
                'Crypto': crypto,
                'Transactions': data['count'],
                'Volume': f"{data['volume']:.8f}",
                'Volume (USD)': f"${volume_usd:,.2f}"
            })
        
        df_crypto = pd.DataFrame(crypto_data)
        st.dataframe(df_crypto, use_container_width=True, hide_index=True)
        
        col_a, col_b = st.columns(2)
        
        with col_a:
            if len(stats['by_crypto']) > 0:
                fig = go.Figure(data=[go.Pie(
                    labels=list(stats['by_crypto'].keys()),
                    values=[d['count'] for d in stats['by_crypto'].values()],
                    hole=.3
                )])
                fig.update_layout(
                    title="Transactions by Crypto",
                    height=400
                )
                st.plotly_chart(fig, use_container_width=True)
        
        with col_b:
            if stats['total_transactions'] > 0:
                status_data = {
                    'Status': ['Pending', 'Confirming', 'Confirmed', 'Failed'],
                    'Count': [stats['pending'], stats['confirming'], stats['confirmed'], stats['failed']]
                }
                
                fig = go.Figure(data=[go.Bar(
                    x=status_data['Status'],
                    y=status_data['Count'],
                    marker_color=['gold', 'blue', 'green', 'red']
                )])
                fig.update_layout(
                    title="Transactions by Status",
                    height=400
                )
                st.plotly_chart(fig, use_container_width=True)
    
    st.markdown("### Live Crypto Prices")
    
    price_data = []
    for crypto, data in prices.items():
        price_data.append({
            'Symbol': data['symbol'],
            'Price (USD)': f"${data['price_usd']:,.2f}",
            '24h Change': f"{data['change_24h']:+.2f}%",
            'Trend': '📈' if data['change_24h'] >= 0 else '📉'
        })
    
    df_prices = pd.DataFrame(price_data)
    st.dataframe(df_prices, use_container_width=True, hide_index=True)
