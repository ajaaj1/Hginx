"""
Main dashboard component for blockchain analytics
"""
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime, timedelta
from utils.calculations import CalculationEngine

def render_dashboard(data_fetcher, selected_networks):
    """Render the main dashboard"""
    
    st.header("📊 Analytics Dashboard")
    
    if not selected_networks:
        st.warning("Please select at least one network from the sidebar.")
        return
    
    # Fetch current data
    with st.spinner("Fetching real-time data..."):
        gas_prices = data_fetcher.get_current_gas_prices(selected_networks)
        network_stats = data_fetcher.get_network_statistics(selected_networks)
    
    # Overview metrics
    st.subheader("🔥 Current Network Overview")
    cols = st.columns(len(selected_networks))
    
    for i, network in enumerate(selected_networks):
        with cols[i]:
            if network in gas_prices and "error" not in gas_prices[network]:
                gas_data = gas_prices[network]
                current_price = gas_data.get('standard_gas_price', gas_data.get('gas_price_gwei', 0))
                
                # Calculate efficiency
                efficiency_data = {}
                if network in network_stats and "error" not in network_stats[network]:
                    efficiency_data = CalculationEngine.calculate_network_efficiency(network_stats[network])
                
                st.metric(
                    label=f"{network} Gas Price",
                    value=f"{current_price:.1f} Gwei",
                    help=f"Current standard gas price for {network}"
                )
                
                if efficiency_data and "efficiency_score" in efficiency_data:
                    st.metric(
                        label="Network Efficiency",
                        value=efficiency_data["efficiency_score"],
                        help=f"Current network efficiency rating"
                    )
                
                if efficiency_data and "utilization_percentage" in efficiency_data:
                    st.metric(
                        label="Network Utilization",
                        value=f"{efficiency_data['utilization_percentage']:.1f}%",
                        help="Percentage of network capacity being used"
                    )
            else:
                st.error(f"Failed to load {network} data")
    
    # Gas price trends
    st.subheader("📈 Gas Price Trends (Last 24 Hours)")
    
    if len(selected_networks) > 0:
        trend_cols = st.columns(len(selected_networks))
        
        for i, network in enumerate(selected_networks):
            with trend_cols[i]:
                history_df = data_fetcher.get_gas_price_history(network, hours=24)
                
                if not history_df.empty:
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(
                        x=history_df['timestamp'],
                        y=history_df['price'],
                        mode='lines+markers',
                        name=f"{network} Gas Price",
                        line=dict(width=2)
                    ))
                    
                    fig.update_layout(
                        title=f"{network} Gas Price History",
                        xaxis_title="Time",
                        yaxis_title="Gas Price (Gwei)",
                        height=300,
                        showlegend=False
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Trend analysis
                    trend_analysis = CalculationEngine.analyze_gas_trends(history_df)
                    if "error" not in trend_analysis:
                        with st.expander(f"📊 {network} Trend Analysis"):
                            col1, col2 = st.columns(2)
                            with col1:
                                st.write(f"**Current Price**: {trend_analysis['current_price']:.2f} Gwei")
                                st.write(f"**24h Average**: {trend_analysis['average_price']:.2f} Gwei")
                                st.write(f"**Volatility**: {trend_analysis['volatility']:.1f}%")
                            with col2:
                                st.write(f"**Trend**: {trend_analysis['trend_direction'].title()}")
                                st.write(f"**24h Change**: {trend_analysis['price_change_24h']:.1f}%")
                                st.write(f"**Min/Max**: {trend_analysis['min_price']:.1f} / {trend_analysis['max_price']:.1f} Gwei")
                else:
                    st.info(f"No historical data available for {network}")
    
    # Network comparison
    if len(selected_networks) > 1:
        st.subheader("⚖️ Network Comparison")
        
        comparison_data = {}
        for network in selected_networks:
            if network in gas_prices and "error" not in gas_prices[network]:
                gas_data = gas_prices[network]
                comparison_data[network] = gas_data
        
        if comparison_data:
            comparison = CalculationEngine.compare_networks(comparison_data)
            
            if "error" not in comparison and comparison["networks"]:
                # Create comparison chart
                df_comparison = pd.DataFrame(comparison["networks"])
                
                fig = go.Figure()
                fig.add_trace(go.Bar(
                    x=df_comparison['network'],
                    y=df_comparison['gas_price_gwei'],
                    name='Gas Price (Gwei)',
                    yaxis='y'
                ))
                
                fig.add_trace(go.Scatter(
                    x=df_comparison['network'],
                    y=df_comparison['utilization'],
                    mode='lines+markers',
                    name='Utilization (%)',
                    yaxis='y2',
                    line=dict(color='red', width=3)
                ))
                
                fig.update_layout(
                    title="Network Comparison: Gas Prices vs Utilization",
                    xaxis_title="Network",
                    yaxis=dict(title="Gas Price (Gwei)", side='left'),
                    yaxis2=dict(title="Utilization (%)", side='right', overlaying='y'),
                    height=400
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Recommendations
                if comparison["recommendations"]:
                    st.subheader("💡 Recommendations")
                    for rec in comparison["recommendations"]:
                        st.success(rec)
    
    # Transaction cost calculator
    st.subheader("💰 Transaction Cost Calculator")
    
    calc_col1, calc_col2 = st.columns(2)
    
    with calc_col1:
        calc_network = st.selectbox("Select Network", selected_networks, key="calc_network")
        gas_limit = st.number_input("Gas Limit", min_value=21000, max_value=1000000, value=21000, step=1000)
        
    with calc_col2:
        if calc_network in gas_prices and "error" not in gas_prices[calc_network]:
            current_gas_price = gas_prices[calc_network].get('standard_gas_price', 
                                                          gas_prices[calc_network].get('gas_price_gwei', 20))
        else:
            current_gas_price = 20
            
        custom_gas_price = st.number_input("Gas Price (Gwei)", min_value=1.0, max_value=500.0, 
                                         value=float(current_gas_price), step=0.1)
    
    if st.button("Calculate Cost", type="primary"):
        cost_data = CalculationEngine.calculate_transaction_cost(gas_limit, custom_gas_price, calc_network)
        
        if "error" not in cost_data:
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Cost in Native Currency", 
                         f"{cost_data['gas_cost_native']:.6f} {cost_data.get('currency', 'ETH')}")
            with col2:
                st.metric("Cost in USD", f"${cost_data['cost_usd']:.2f}")
            with col3:
                st.metric("Exchange Rate", f"${cost_data['exchange_rate']:.2f}")
        else:
            st.error(f"Error calculating cost: {cost_data['error']}")
    
    # Real-time alerts section
    st.subheader("🚨 Gas Price Alerts")
    
    alert_col1, alert_col2 = st.columns(2)
    
    with alert_col1:
        alert_network = st.selectbox("Network", selected_networks, key="alert_network")
        target_price = st.number_input("Target Gas Price (Gwei)", min_value=1.0, max_value=200.0, value=20.0, step=0.5)
        
    with alert_col2:
        if alert_network in gas_prices and "error" not in gas_prices[alert_network]:
            current_price = gas_prices[alert_network].get('standard_gas_price', 
                                                        gas_prices[alert_network].get('gas_price_gwei', 20))
            
            if current_price <= target_price:
                st.success(f"🎯 Target reached! Current price: {current_price:.1f} Gwei")
            else:
                st.info(f"⏳ Waiting... Current: {current_price:.1f} Gwei (Target: {target_price:.1f})")
                
                savings_data = CalculationEngine.calculate_gas_savings(current_price, target_price, 21000)
                if "error" not in savings_data:
                    st.write(f"💰 Potential savings: {savings_data['savings_percentage']:.1f}%")
