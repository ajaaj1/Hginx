"""
Transaction monitoring component
"""
import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime
from utils.calculations import CalculationEngine

def render_transaction_monitor(data_fetcher, selected_networks):
    """Render the transaction monitoring page"""
    
    st.header("🔍 Transaction Monitor")
    
    if not selected_networks:
        st.warning("Please select at least one network from the sidebar.")
        return
    
    # Transaction search section
    st.subheader("🔎 Transaction Search")
    
    search_col1, search_col2 = st.columns([3, 1])
    
    with search_col1:
        tx_hash = st.text_input("Enter Transaction Hash", 
                               placeholder="0x1234567890abcdef...",
                               help="Enter a transaction hash to search across selected networks")
    
    with search_col2:
        st.write("")  # Spacing
        search_button = st.button("Search Transaction", type="primary")
    
    if search_button and tx_hash:
        if len(tx_hash) < 10:
            st.error("❌ Please enter a valid transaction hash")
        else:
            with st.spinner(f"Searching across {', '.join(selected_networks)}..."):
                tx_data = data_fetcher.search_transaction(tx_hash, selected_networks)
                
                if tx_data:
                    st.success(f"✅ Transaction found on {tx_data['network']}")
                    
                    # Display transaction details
                    st.subheader("📄 Transaction Details")
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.write(f"**Hash**: `{tx_data['hash']}`")
                        st.write(f"**Network**: {tx_data['network']}")
                        st.write(f"**From**: `{tx_data['from']}`")
                        st.write(f"**To**: `{tx_data.get('to', 'Contract Creation')}`")
                        
                    with col2:
                        st.write(f"**Value**: {int(tx_data.get('value', '0')) / 1e18:.6f} ETH")
                        st.write(f"**Gas Limit**: {tx_data.get('gas', 0):,}")
                        st.write(f"**Gas Price**: {int(tx_data.get('gas_price', '0')) / 1e9:.2f} Gwei")
                        
                        if tx_data.get('status') is not None:
                            status_emoji = "✅" if tx_data['status'] == 1 else "❌"
                            status_text = "Success" if tx_data['status'] == 1 else "Failed"
                            st.write(f"**Status**: {status_emoji} {status_text}")
                        
                        if tx_data.get('block_number'):
                            st.write(f"**Block Number**: {tx_data['block_number']:,}")
                    
                    # Gas cost analysis
                    if tx_data.get('gas') and tx_data.get('gas_price'):
                        gas_limit = tx_data['gas']
                        gas_price_gwei = int(tx_data['gas_price']) / 1e9
                        
                        cost_analysis = CalculationEngine.calculate_transaction_cost(
                            gas_limit, gas_price_gwei, tx_data['network']
                        )
                        
                        if "error" not in cost_analysis:
                            st.subheader("💰 Cost Analysis")
                            
                            cost_col1, cost_col2, cost_col3 = st.columns(3)
                            
                            with cost_col1:
                                st.metric("Gas Used", f"{gas_limit:,}")
                                
                            with cost_col2:
                                currency = cost_analysis.get('currency', 'ETH')
                                st.metric(f"Cost ({currency})", f"{cost_analysis['gas_cost_native']:.6f}")
                                
                            with cost_col3:
                                st.metric("Cost (USD)", f"${cost_analysis['cost_usd']:.2f}")
                
                else:
                    st.error(f"❌ Transaction not found on any selected network")
                    st.info("💡 Make sure the transaction hash is correct and the network is selected")
    
    # Mempool monitoring
    st.subheader("🏊‍♂️ Mempool Activity")
    
    mempool_cols = st.columns(len(selected_networks))
    
    for i, network in enumerate(selected_networks):
        with mempool_cols[i]:
            with st.spinner(f"Loading {network} mempool..."):
                mempool_data = data_fetcher.get_mempool_data(network)
                
                if "error" not in mempool_data:
                    st.markdown(f"### {network}")
                    
                    # Pending transactions metric
                    st.metric(
                        "Pending Transactions", 
                        f"{mempool_data['pending_transactions']:,}",
                        help="Estimated number of pending transactions"
                    )
                    
                    # Congestion level
                    congestion = mempool_data.get('congestion_level', 'Unknown')
                    congestion_colors = {
                        'Low': '🟢',
                        'Medium': '🟡', 
                        'High': '🔴'
                    }
                    
                    st.write(f"**Congestion**: {congestion_colors.get(congestion, '⚪')} {congestion}")
                    
                    # Average gas price
                    avg_gas = mempool_data.get('average_gas_price', 0)
                    st.write(f"**Avg Gas Price**: {avg_gas:.1f} Gwei")
                    
                    # Estimated clear time
                    clear_time = mempool_data.get('estimated_clear_time', 'Unknown')
                    st.write(f"**Est. Clear Time**: {clear_time}")
                    
                else:
                    st.error(f"❌ Failed to load {network} mempool data")
    
    # Transaction cost simulator
    st.subheader("🧮 Transaction Cost Simulator")
    
    st.write("Simulate transaction costs for different scenarios")
    
    sim_col1, sim_col2, sim_col3 = st.columns(3)
    
    with sim_col1:
        sim_network = st.selectbox("Network", selected_networks, key="sim_network")
        transaction_type = st.selectbox("Transaction Type", [
            "Simple Transfer (21,000 gas)",
            "ERC-20 Transfer (65,000 gas)", 
            "Uniswap Swap (150,000 gas)",
            "NFT Mint (200,000 gas)",
            "Contract Deploy (500,000 gas)",
            "Custom"
        ])
        
    with sim_col2:
        # Gas limit based on transaction type
        gas_limits = {
            "Simple Transfer (21,000 gas)": 21000,
            "ERC-20 Transfer (65,000 gas)": 65000,
            "Uniswap Swap (150,000 gas)": 150000,
            "NFT Mint (200,000 gas)": 200000,
            "Contract Deploy (500,000 gas)": 500000,
            "Custom": 50000
        }
        
        default_gas = gas_limits.get(transaction_type, 50000)
        sim_gas_limit = st.number_input("Gas Limit", 
                                       min_value=21000, 
                                       max_value=10000000, 
                                       value=default_gas,
                                       step=1000,
                                       key="sim_gas_limit")
        
        # Get current gas prices for the network
        gas_prices = data_fetcher.get_current_gas_prices([sim_network])
        current_gas = 20.0  # default
        
        if sim_network in gas_prices and "error" not in gas_prices[sim_network]:
            gas_data = gas_prices[sim_network]
            current_gas = gas_data.get('standard_gas_price', gas_data.get('gas_price_gwei', 20.0))
        
    with sim_col3:
        gas_price_scenarios = [
            ("Current", current_gas),
            ("Low (+0 Gwei)", current_gas),
            ("Medium (+5 Gwei)", current_gas + 5),
            ("High (+15 Gwei)", current_gas + 15),
            ("Custom", current_gas)
        ]
        
        scenario = st.selectbox("Gas Price Scenario", [s[0] for s in gas_price_scenarios])
        
        if scenario == "Custom":
            sim_gas_price = st.number_input("Gas Price (Gwei)", 
                                          min_value=1.0, 
                                          max_value=500.0, 
                                          value=current_gas,
                                          step=0.1,
                                          key="sim_gas_price")
        else:
            sim_gas_price = dict(gas_price_scenarios)[scenario]
            st.write(f"Gas Price: {sim_gas_price:.1f} Gwei")
    
    if st.button("Calculate Costs", type="primary"):
        # Calculate costs for different scenarios
        scenarios = [
            ("Economy (-20%)", sim_gas_price * 0.8),
            ("Standard", sim_gas_price),
            ("Fast (+20%)", sim_gas_price * 1.2),
            ("Rapid (+50%)", sim_gas_price * 1.5)
        ]
        
        st.subheader("💸 Cost Breakdown")
        
        results = []
        for scenario_name, gas_price in scenarios:
            cost_data = CalculationEngine.calculate_transaction_cost(sim_gas_limit, gas_price, sim_network)
            if "error" not in cost_data:
                results.append({
                    "Scenario": scenario_name,
                    "Gas Price (Gwei)": f"{gas_price:.1f}",
                    "Cost (Native)": f"{cost_data['gas_cost_native']:.6f} {cost_data.get('currency', 'ETH')}",
                    "Cost (USD)": f"${cost_data['cost_usd']:.2f}"
                })
        
        if results:
            df_results = pd.DataFrame(results)
            st.dataframe(df_results, use_container_width=True, hide_index=True)
            
            # Create cost comparison chart
            fig = go.Figure()
            
            fig.add_trace(go.Bar(
                x=df_results['Scenario'],
                y=[float(cost.replace('$', '')) for cost in df_results['Cost (USD)']],
                name='Transaction Cost (USD)',
                marker_color=['green', 'blue', 'orange', 'red']
            ))
            
            fig.update_layout(
                title="Transaction Cost Comparison",
                xaxis_title="Scenario",
                yaxis_title="Cost (USD)",
                height=400
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Savings analysis
            standard_cost = next(r for r in results if r['Scenario'] == 'Standard')['Cost (USD)']
            economy_cost = next(r for r in results if r['Scenario'] == 'Economy (-20%)')['Cost (USD)']
            
            standard_usd = float(standard_cost.replace('$', ''))
            economy_usd = float(economy_cost.replace('$', ''))
            
            savings = standard_usd - economy_usd
            savings_pct = (savings / standard_usd) * 100 if standard_usd > 0 else 0
            
            if savings > 0:
                st.success(f"💰 You could save ${savings:.2f} ({savings_pct:.1f}%) by using economy gas price")
    
    # Transaction history analysis (placeholder for user's transactions)
    st.subheader("📊 Transaction Analysis Tips")
    
    with st.expander("💡 Gas Optimization Tips"):
        st.markdown("""
        **Optimize Your Transaction Costs:**
        
        1. **Timing Matters**: Gas prices fluctuate throughout the day. Use the Gas Tracker to find optimal times.
        
        2. **Transaction Types**: 
           - Simple transfers: ~21,000 gas
           - ERC-20 transfers: ~65,000 gas  
           - DeFi swaps: 150,000-300,000 gas
           - NFT mints: 200,000+ gas
        
        3. **Speed vs Cost**: Choose gas price based on urgency:
           - Economy: Save money, wait longer
           - Standard: Balanced approach
           - Fast: Pay premium for quick confirmation
        
        4. **Network Selection**: Compare costs across Ethereum, Polygon, and BSC
        
        5. **Batch Transactions**: Group multiple operations when possible
        """)
    
    with st.expander("🔍 Understanding Transaction Status"):
        st.markdown("""
        **Transaction States:**
        
        - **Pending**: Transaction is in mempool waiting for confirmation
        - **Confirmed**: Transaction included in a block (1+ confirmations)  
        - **Failed**: Transaction reverted due to error or insufficient gas
        - **Dropped**: Transaction removed from mempool (usually due to low gas price)
        
        **Confirmation Times:**
        - 1 confirmation: Transaction in latest block
        - 3+ confirmations: Generally safe for small amounts
        - 12+ confirmations: Recommended for large amounts
        """)
