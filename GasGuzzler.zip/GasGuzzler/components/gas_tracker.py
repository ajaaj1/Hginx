"""
Gas price tracking component
"""
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime, timedelta
from utils.calculations import CalculationEngine

def render_gas_tracker(data_fetcher, selected_networks):
    """Render the gas tracker page"""
    
    st.header("⛽ Gas Price Tracker")
    
    if not selected_networks:
        st.warning("Please select at least one network from the sidebar.")
        return
    
    # Current gas prices
    st.subheader("🔥 Current Gas Prices")
    
    with st.spinner("Fetching current gas prices..."):
        gas_prices = data_fetcher.get_current_gas_prices(selected_networks)
    
    # Display current prices in cards
    cols = st.columns(len(selected_networks))
    
    for i, network in enumerate(selected_networks):
        with cols[i]:
            if network in gas_prices and "error" not in gas_prices[network]:
                gas_data = gas_prices[network]
                
                # Create a nice card layout
                with st.container():
                    st.markdown(f"### {network}")
                    
                    # Different price tiers if available
                    if 'safe_gas_price' in gas_data:
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("🐌 Safe", f"{gas_data['safe_gas_price']:.1f} Gwei", 
                                    help="Slower transaction, lower cost")
                        with col2:
                            st.metric("⚡ Standard", f"{gas_data['standard_gas_price']:.1f} Gwei",
                                    help="Standard speed and cost")
                        with col3:
                            st.metric("🚀 Fast", f"{gas_data['fast_gas_price']:.1f} Gwei",
                                    help="Faster transaction, higher cost")
                    else:
                        st.metric("Current Price", f"{gas_data.get('gas_price_gwei', 0):.1f} Gwei")
                    
                    # Last updated
                    if 'timestamp' in gas_data:
                        last_update = datetime.fromtimestamp(gas_data['timestamp'])
                        st.caption(f"Last updated: {last_update.strftime('%H:%M:%S')}")
                        
            else:
                st.error(f"❌ Failed to load {network} data")
                if network in gas_prices:
                    st.caption(f"Error: {gas_prices[network].get('error', 'Unknown error')}")
    
    # Historical trends
    st.subheader("📈 Historical Gas Price Trends")
    
    # Time range selector
    time_range = st.selectbox("Select Time Range", 
                             ["1 Hour", "6 Hours", "24 Hours", "7 Days"], 
                             index=2)
    
    hours_map = {"1 Hour": 1, "6 Hours": 6, "24 Hours": 24, "7 Days": 168}
    hours = hours_map[time_range]
    
    if len(selected_networks) == 1:
        # Single network detailed view
        network = selected_networks[0]
        history_df = data_fetcher.get_gas_price_history(network, hours=hours)
        
        if not history_df.empty:
            fig = go.Figure()
            
            fig.add_trace(go.Scatter(
                x=history_df['timestamp'],
                y=history_df['price'],
                mode='lines',
                name=f"{network} Gas Price",
                line=dict(width=2, color='#1f77b4'),
                fill='tonexty' if len(history_df) > 10 else None
            ))
            
            # Add moving average
            if len(history_df) >= 10:
                history_df['ma'] = history_df['price'].rolling(window=10, center=True).mean()
                fig.add_trace(go.Scatter(
                    x=history_df['timestamp'],
                    y=history_df['ma'],
                    mode='lines',
                    name='Moving Average (10 periods)',
                    line=dict(width=2, color='red', dash='dash')
                ))
            
            fig.update_layout(
                title=f"{network} Gas Price History ({time_range})",
                xaxis_title="Time",
                yaxis_title="Gas Price (Gwei)",
                height=500,
                hovermode='x unified'
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Statistical analysis
            trend_analysis = CalculationEngine.analyze_gas_trends(history_df)
            if "error" not in trend_analysis:
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("Average", f"{trend_analysis['average_price']:.2f} Gwei")
                    st.metric("Median", f"{trend_analysis['median_price']:.2f} Gwei")
                
                with col2:
                    st.metric("Min", f"{trend_analysis['min_price']:.2f} Gwei")
                    st.metric("Max", f"{trend_analysis['max_price']:.2f} Gwei")
                
                with col3:
                    st.metric("Volatility", f"{trend_analysis['volatility']:.1f}%")
                    st.metric("Std Dev", f"{trend_analysis['std_deviation']:.2f}")
                
                with col4:
                    trend_emoji = "📈" if trend_analysis['trend_direction'] == "increasing" else "📉" if trend_analysis['trend_direction'] == "decreasing" else "➡️"
                    st.metric("Trend", f"{trend_emoji} {trend_analysis['trend_direction'].title()}")
                    st.metric("Change", f"{trend_analysis['price_change_24h']:.1f}%")
        else:
            st.info(f"No historical data available for {network} in the selected time range.")
    
    else:
        # Multi-network comparison
        fig = go.Figure()
        
        for network in selected_networks:
            history_df = data_fetcher.get_gas_price_history(network, hours=hours)
            
            if not history_df.empty:
                fig.add_trace(go.Scatter(
                    x=history_df['timestamp'],
                    y=history_df['price'],
                    mode='lines',
                    name=f"{network}",
                    line=dict(width=2)
                ))
        
        fig.update_layout(
            title=f"Gas Price Comparison ({time_range})",
            xaxis_title="Time",
            yaxis_title="Gas Price (Gwei)",
            height=500,
            hovermode='x unified'
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    # Gas optimization recommendations
    st.subheader("💡 Gas Optimization Recommendations")
    
    rec_network = st.selectbox("Select Network for Recommendations", selected_networks)
    
    if st.button("Get Optimization Recommendations", type="primary"):
        with st.spinner("Analyzing network conditions..."):
            recommendations = data_fetcher.calculate_optimal_gas_price(rec_network)
            
            if "error" not in recommendations:
                st.success("✅ Analysis complete!")
                
                # Display recommendations
                rec_data = recommendations.get("recommendations", {})
                status = rec_data.get("status", "unknown")
                
                # Status indicator
                status_colors = {
                    "low_congestion": "🟢",
                    "medium_congestion": "🟡", 
                    "high_congestion": "🔴"
                }
                
                st.markdown(f"**Network Status**: {status_colors.get(status, '⚪')} {status.replace('_', ' ').title()}")
                st.markdown(f"**Current Utilization**: {recommendations.get('network_utilization', 0):.1f}%")
                
                if rec_data:
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("🐌 Economy", f"{rec_data['slow']:.1f} Gwei",
                                help=rec_data.get('wait_time_estimates', {}).get('slow', 'Unknown wait time'))
                    
                    with col2:
                        st.metric("⚡ Standard", f"{rec_data['standard']:.1f} Gwei",
                                help=rec_data.get('wait_time_estimates', {}).get('standard', 'Unknown wait time'))
                    
                    with col3:
                        st.metric("🚀 Fast", f"{rec_data['fast']:.1f} Gwei",
                                help=rec_data.get('wait_time_estimates', {}).get('fast', 'Unknown wait time'))
                    
                    # Wait time estimates
                    wait_times = rec_data.get('wait_time_estimates', {})
                    if wait_times:
                        st.subheader("⏱️ Estimated Confirmation Times")
                        for speed, time_est in wait_times.items():
                            st.write(f"**{speed.title()}**: {time_est}")
            else:
                st.error(f"❌ Error getting recommendations: {recommendations['error']}")
    
    # Optimal timing predictor
    st.subheader("🎯 Optimal Timing Predictor")
    
    timing_network = st.selectbox("Select Network for Timing Analysis", selected_networks, key="timing_network")
    target_gas_price = st.number_input("Target Gas Price (Gwei)", min_value=1.0, max_value=200.0, value=20.0, step=0.5)
    
    if st.button("Analyze Optimal Timing", type="secondary"):
        with st.spinner("Analyzing historical patterns..."):
            history_df = data_fetcher.get_gas_price_history(timing_network, hours=168)  # 7 days
            
            if not history_df.empty:
                prediction = CalculationEngine.predict_optimal_timing(history_df, target_gas_price)
                
                if "error" not in prediction:
                    st.success("📊 Timing analysis complete!")
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.metric("Current Price", f"{prediction['current_price']:.2f} Gwei")
                        st.metric("Target Price", f"{prediction['target_price']:.2f} Gwei")
                        
                        if prediction['recommendation'] == 'wait':
                            st.warning(f"⏳ Recommend waiting {prediction['estimated_wait_hours']} hours")
                        else:
                            st.success("✅ Good time to execute transaction!")
                    
                    with col2:
                        # Best times
                        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
                        best_day = days[prediction['best_day_of_week']]
                        
                        st.metric("Best Hour (UTC)", f"{prediction['best_hour_utc']:02d}:00")
                        st.metric("Best Day", best_day)
                    
                    # Hourly pattern chart
                    if prediction.get('hourly_averages'):
                        hourly_data = prediction['hourly_averages']
                        
                        fig = go.Figure()
                        fig.add_trace(go.Bar(
                            x=list(hourly_data.keys()),
                            y=list(hourly_data.values()),
                            name='Average Gas Price by Hour'
                        ))
                        
                        # Highlight best hour
                        fig.add_vline(x=prediction['best_hour_utc'], 
                                    line_dash="dash", 
                                    line_color="green",
                                    annotation_text="Best Hour")
                        
                        fig.update_layout(
                            title="Average Gas Prices by Hour (UTC)",
                            xaxis_title="Hour",
                            yaxis_title="Gas Price (Gwei)",
                            height=400
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
                        
                else:
                    st.error(f"❌ Error in timing analysis: {prediction['error']}")
            else:
                st.info("Insufficient historical data for timing analysis.")
