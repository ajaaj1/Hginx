# Blockchain Analytics Platform

## Overview

A comprehensive blockchain analytics platform built with Streamlit that provides real-time monitoring and analysis of blockchain networks. The application focuses on gas fee tracking, transaction monitoring, transaction simulation, and network performance analysis across multiple blockchain networks including Ethereum, Polygon, and Binance Smart Chain (BSC).

The platform offers a multi-page web interface with interactive dashboards, real-time data fetching, and advanced analytics capabilities. Users can track gas prices, monitor transactions, simulate crypto transactions with realistic data, analyze network performance, and make informed decisions about blockchain interactions.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### November 2025
- Fixed Web3 API compatibility issues (updated from deprecated `isConnected` to `is_connected`)
- Added fallback/simulated data when external APIs are unavailable
- Added comprehensive Transaction Simulator with multi-cryptocurrency support
- Implemented wallet address generator for 10 major cryptocurrencies
- Added transaction hash/ID generation with real-time confirmation tracking
- Built confirmation tampering/editing feature for testing scenarios

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit-based web application with multi-page navigation
- **UI Components**: Modular component architecture with separate files for dashboard, gas tracker, transaction monitor, network analyzer, and transaction simulator
- **Visualization**: Plotly integration for interactive charts and graphs
- **Layout**: Wide layout with expandable sidebar navigation and responsive column layouts
- **State Management**: Streamlit's session state and caching mechanisms for performance optimization

### Backend Architecture
- **Data Layer**: Centralized DataFetcher class with built-in caching mechanism (30-second cache duration)
- **Calculation Engine**: Dedicated CalculationEngine for blockchain-specific computations including transaction costs, gas savings, and network efficiency metrics
- **Blockchain Utilities**: BlockchainUtils class for direct blockchain network interactions with fallback support
- **Transaction Simulator**: TransactionSimulator class for generating realistic crypto transactions
- **Network Support**: Multi-network architecture supporting Ethereum, Polygon, and BSC with configurable endpoints
- **Async Operations**: Threading and asyncio support for concurrent data fetching

### Transaction Simulator Features
- **Supported Cryptocurrencies**: BTC, ETH, LTC, USDT, USDC, BNB, XRP, DOGE, SOL, MATIC
- **Wallet Generation**: Creates realistic wallet addresses with crypto-specific formats
- **Transaction Creation**: Generates unique transaction IDs and hashes
- **Confirmation Tracking**: Real-time confirmation status updates (pending, confirming, confirmed)
- **Manual Override**: Ability to manually adjust confirmations and transaction status
- **Statistics Dashboard**: Transaction volume and status analytics with charts

### Data Management
- **Caching Strategy**: Time-based caching system to reduce API calls and improve performance
- **Real-time Data**: Live blockchain data fetching with automatic refresh capabilities
- **Fallback System**: Simulated data generation when external APIs are unavailable
- **Data Processing**: Pandas and NumPy for data manipulation and analysis
- **Historical Tracking**: Gas price history storage and trend analysis

### Network Integration
- **RPC Connections**: Web3.py integration for direct blockchain node communication
- **API Integrations**: Support for Etherscan, Polygonscan, and BSCScan APIs
- **Multi-chain Support**: Unified interface for interacting with different blockchain networks
- **Error Handling**: Comprehensive error handling with graceful fallbacks for network failures

## External Dependencies

### Blockchain APIs and Services
- **Etherscan API**: Ethereum network data and transaction information
- **Polygonscan API**: Polygon network statistics and transaction details
- **BSCScan API**: Binance Smart Chain network data and analytics
- **LlamaRPC**: Public RPC endpoints for blockchain connectivity
- **Binance RPC**: Direct BSC network connectivity

### Development Libraries
- **Streamlit**: Web application framework for the user interface
- **Plotly**: Interactive data visualization and charting
- **Web3.py**: Ethereum blockchain interaction library
- **Pandas**: Data manipulation and analysis
- **NumPy**: Numerical computing for analytics calculations
- **Requests**: HTTP library for API interactions

### Configuration Dependencies
- **Environment Variables**: API keys and RPC URLs configuration (optional)
- **Python Standard Libraries**: datetime, time, os, logging, threading, secrets, hashlib
- **Exchange Rate APIs**: Simulated cryptocurrency price data

### Infrastructure Requirements
- **API Rate Limiting**: Consideration for blockchain API rate limits
- **Caching System**: In-memory caching for performance optimization
- **Error Recovery**: Robust error handling with fallback data generation
- **Scalability**: Modular architecture supporting additional blockchain networks

## File Structure

```
/
├── app.py                          # Main Streamlit application entry point
├── components/
│   ├── dashboard.py                # Main analytics dashboard
│   ├── gas_tracker.py              # Gas price tracking component
│   ├── transaction_monitor.py      # Transaction monitoring component
│   ├── network_analyzer.py         # Network analysis component
│   └── transaction_simulator.py    # Transaction simulator UI component
├── utils/
│   ├── blockchain_utils.py         # Blockchain interaction utilities
│   ├── calculations.py             # Calculation engine
│   ├── data_fetcher.py             # Data fetching and caching
│   └── transaction_simulator.py    # Transaction simulation logic
├── .streamlit/
│   └── config.toml                 # Streamlit configuration
└── replit.md                       # Project documentation
```
